
export enum UserRole {
  PARENT = 'PARENT',
  TEACHER = 'TEACHER',
  ADMIN = 'ADMIN',
  STUDENT = 'STUDENT'
}

export enum GameType {
  SPELLING = 'SPELLING',
  MATH = 'MATH',
  ANIMALS = 'ANIMALS',
  VIDEO = 'VIDEO'
}

export interface User {
  uid: string;
  email: string;
  role: UserRole;
  displayName: string;
  isVerified?: boolean; // For teachers
  subscriptionStatus?: 'free' | 'premium';
}

export interface StudentProfile {
  id: string;
  parentId: string;
  name: string;
  age: number;
  avatar: string;
  stars: number;
  streak: number;
  lastLoginDate: string;
}

export interface MasteryRecord {
  studentId: string;
  subject: GameType;
  score: number;
  timestamp: number;
}

export interface TeacherProfile {
  id: string;
  name: string;
  bio: string;
  subjects: string[];
  hourlyRate: number;
  isVerified: boolean;
  availability: string;
  rating: number;
  reviews: number;
  location: string;
}

export interface SpellingWord {
  id: string;
  word: string;
  image: string; // URL or emoji
  category: 'animals' | 'objects' | 'food';
  sentence?: string;
}

export interface Quest {
  id: string;
  title: string;
  targetCount: number;
  rewardStars: number;
  type: GameType;
}

export interface PlaylistItem {
  youtubeId: string;
  title: string;
  duration: string;
}

export interface Video {
  id: string;
  youtubeId: string; // For single videos, this is the video ID. For playlists, the playlist ID.
  title: string;
  category: 'Alphabet' | 'Math' | 'Colors' | 'Science' | 'Social Studies' | 'Reading';
  type: 'video' | 'playlist';
  duration?: string;
  isPremium?: boolean;
  playlistItems?: PlaylistItem[]; // Optional list of videos if type is playlist
}
