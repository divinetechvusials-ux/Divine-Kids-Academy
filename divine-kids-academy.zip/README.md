# Divine Kids Academy

A child-safe, educational PWA built for Divine Tech Company Limited.

## Tech Stack
- Frontend: React 18, Tailwind CSS, Lucide Icons, Recharts
- Backend: Firebase (Auth, Firestore, Functions)

## Getting Started

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Run Locally**:
   ```bash
   npm run dev
   ```

3. **Build for Production**:
   ```bash
   npm run build
   ```

## Firebase Setup

1. Create a project at [console.firebase.google.com](https://console.firebase.google.com).
2. Enable Authentication (Email/Password).
3. Enable Firestore Database.
4. Install Firebase CLI: `npm install -g firebase-tools`.
5. Login: `firebase login`.
6. Initialize: `firebase init`.
   - Select Hosting and Functions.
   - Use the `dist` (or `build`) folder for hosting.
7. Deploy:
   ```bash
   firebase deploy
   ```

## Android PWA Wrapper (TWA)

To publish to the Google Play Store:
1. Use [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap) CLI.
2. Initialize: `bubblewrap init --manifest=https://your-app-url.web.app/manifest.json`.
3. Build: `bubblewrap build`.
4. Upload the generated `.aab` file to Play Console.

## COPPA Compliance
This app includes a mandatory parental consent modal (`CoppaModal.tsx`) before account creation. Data collection is minimized.

## Admin
Author: Divine Simon Turay
Support: +23234547720
