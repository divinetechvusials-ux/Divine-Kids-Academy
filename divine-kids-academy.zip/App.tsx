
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { BubbleButton, Mascot } from './components/UIComponents';
import { MobileAuth } from './components/MobileAuth';
import { SpellingGame } from './views/SpellingGame';
import { AnimalGame } from './views/AnimalGame';
import { MathGame } from './views/MathGame';
import { VideoView } from './views/VideoView';
import { ParentDashboard } from './views/ParentDashboard';
import { TeacherMarketplace } from './views/TeacherMarketplace';
import { AboutView } from './views/AboutView';
import { AlphabetView } from './views/AlphabetView';
import { SongsView } from './views/SongsView';
import { SplashScreen } from './components/SplashScreen';
import { Home, Gamepad2, PieChart, Users, Settings, MessageCircle, Lock, Star, Info, Type, Music, Volume2, VolumeX } from 'lucide-react';
import { SUPPORT_NUMBERS } from './constants';
import { initBackgroundMusic, toggleBackgroundMusic, startBackgroundMusic } from './utils/soundUtils';
import { ErrorBoundary } from './components/ErrorBoundary';

const HomeView: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-6 pb-24">
      <div className="text-center mb-8 pt-8">
        <Mascot type="sun" className="mx-auto mb-4" />
        <h1 className="text-4xl font-extrabold text-[#9C27B0] drop-shadow-sm font-[Fredoka]">Divine Kids Academy</h1>
        <p className="text-gray-600 mt-2 font-semibold">Ready to learn, Alex?</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Alphabet - New */}
        <div 
          onClick={() => navigate('/alphabet')}
          className="bg-white aspect-square rounded-3xl p-4 flex flex-col items-center justify-center text-[#6EC6FF] shadow-lg cursor-pointer transform hover:scale-105 transition-transform border-b-8 border-gray-100 ring-4 ring-blue-50"
        >
          <span className="text-6xl mb-2 font-black">Aa</span>
          <span className="font-bold text-xl text-center text-gray-600">Alphabet</span>
        </div>

        <div 
          onClick={() => navigate('/songs')}
          className="bg-[#9C27B0] aspect-square rounded-3xl p-4 flex flex-col items-center justify-center text-white shadow-lg cursor-pointer transform hover:scale-105 transition-transform border-b-8 border-purple-800"
        >
          <span className="text-6xl mb-2">🎵</span>
          <span className="font-bold text-xl text-center">Sing Along</span>
        </div>

        <div 
          onClick={() => navigate('/spelling')}
          className="bg-[#6EC6FF] aspect-square rounded-3xl p-4 flex flex-col items-center justify-center text-white shadow-lg cursor-pointer transform hover:scale-105 transition-transform border-b-8 border-[#5ac0ff]"
        >
          <span className="text-6xl mb-2">🔡</span>
          <span className="font-bold text-xl text-center">Spelling</span>
        </div>
        <div 
          onClick={() => navigate('/math')}
          className="bg-[#4CAF50] aspect-square rounded-3xl p-4 flex flex-col items-center justify-center text-white shadow-lg cursor-pointer transform hover:scale-105 transition-transform border-b-8 border-[#43a047]"
        >
          <span className="text-6xl mb-2">🍎</span>
          <span className="font-bold text-xl text-center">Math & Shapes</span>
        </div>
        <div 
          onClick={() => navigate('/animals')}
          className="bg-[#FFD54F] aspect-square rounded-3xl p-4 flex flex-col items-center justify-center text-[#5D4037] shadow-lg cursor-pointer transform hover:scale-105 transition-transform border-b-8 border-[#ffcf40]"
        >
          <span className="text-6xl mb-2">🦁</span>
          <span className="font-bold text-xl">Animals</span>
        </div>
        <div 
          onClick={() => navigate('/videos')}
          className="bg-[#FF5252] aspect-square rounded-3xl p-4 flex flex-col items-center justify-center text-white shadow-lg cursor-pointer transform hover:scale-105 transition-transform border-b-8 border-[#ff1744] col-span-2"
        >
          <span className="text-6xl mb-2">🎬</span>
          <span className="font-bold text-xl">Video Classroom</span>
        </div>
      </div>

      <div className="bg-purple-100 p-6 rounded-2xl flex items-center justify-between border-2 border-purple-200">
        <div>
          <h3 className="font-bold text-purple-900">Daily Streak</h3>
          <p className="text-purple-600 text-sm">You are on fire! 🔥</p>
        </div>
        <div className="flex gap-1">
           {[1,2,3].map(i => <Star key={i} className="text-yellow-500 fill-yellow-500" />)}
           <Star className="text-gray-300" />
        </div>
      </div>
    </div>
  );
};

const MainLayout: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMusicOn, setIsMusicOn] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // Initial check for authentication
  useEffect(() => {
    const authSession = localStorage.getItem('dka_auth');
    if (authSession === 'true') {
        setIsAuthenticated(true);
        initBackgroundMusic();
    }

    const handleFirstInteraction = () => {
        if (localStorage.getItem('dka_auth') === 'true') {
            const playing = startBackgroundMusic();
            if (playing) setIsMusicOn(true);
        }
    };

    window.addEventListener('click', handleFirstInteraction, { once: true });
    window.addEventListener('touchstart', handleFirstInteraction, { once: true });

    return () => {
        window.removeEventListener('click', handleFirstInteraction);
        window.removeEventListener('touchstart', handleFirstInteraction);
    };
  }, []);

  const handleAuthentication = (phone: string) => {
    localStorage.setItem('dka_auth', 'true');
    localStorage.setItem('user_phone', phone);
    setIsAuthenticated(true);
    const playing = startBackgroundMusic();
    setIsMusicOn(playing);
  };

  const handleMusicToggle = () => {
      const playing = toggleBackgroundMusic();
      setIsMusicOn(playing);
  };

  const openWhatsApp = () => {
    window.open(`https://wa.me/${SUPPORT_NUMBERS.SIERRA_LEONE.replace('+', '')}`, '_blank');
  };

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  if (!isAuthenticated) {
    return <MobileAuth onAuthenticated={handleAuthentication} />;
  }

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-[#F0F9FF] font-[Fredoka] flex flex-col md:flex-row animate-fade-in">
      {/* Mobile Header */}
      <div className="md:hidden bg-white p-4 flex justify-between items-center shadow-sm z-20 sticky top-0">
        <span className="font-bold text-lg text-[#6EC6FF]">Divine Kids</span>
        <div className="flex gap-2">
            <button onClick={handleMusicToggle} className="p-2 bg-purple-50 rounded-full text-purple-600">
                {isMusicOn ? <Volume2 size={20} /> : <VolumeX size={20} />}
            </button>
            <button className="p-2 bg-gray-100 rounded-full text-green-600 font-bold text-xs" onClick={openWhatsApp}>
            Help?
            </button>
        </div>
      </div>

      <main className="flex-1 overflow-y-auto min-h-screen">
        <ErrorBoundary>
            <Routes>
            <Route path="/" element={<HomeView />} />
            <Route path="/alphabet" element={<AlphabetView onExit={() => navigate('/')} />} />
            <Route path="/songs" element={<SongsView onExit={() => navigate('/')} />} />
            <Route path="/spelling" element={<SpellingGame onExit={() => navigate('/')} />} />
            <Route path="/animals" element={<AnimalGame onExit={() => navigate('/')} />} />
            <Route path="/math" element={<MathGame onExit={() => navigate('/')} />} />
            <Route path="/videos" element={<VideoView onExit={() => navigate('/')} />} />
            <Route path="/dashboard" element={<ParentDashboard />} />
            <Route path="/teachers" element={<TeacherMarketplace />} />
            <Route path="/about" element={<AboutView onExit={() => navigate('/')} />} />
            </Routes>
        </ErrorBoundary>
      </main>

      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-[0_-4px_20px_rgba(0,0,0,0.1)] p-4 flex justify-around items-center z-30 rounded-t-3xl">
        <button onClick={() => navigate('/')} className={`p-2 rounded-xl ${isActive('/') ? 'text-[#6EC6FF] bg-blue-50' : 'text-gray-400'}`}>
          <Home size={28} />
        </button>
        <button onClick={() => navigate('/dashboard')} className={`p-2 rounded-xl ${isActive('/dashboard') ? 'text-[#6EC6FF] bg-blue-50' : 'text-gray-400'}`}>
          <PieChart size={28} />
        </button>
        <button onClick={() => navigate('/teachers')} className={`p-2 rounded-xl ${isActive('/teachers') ? 'text-[#6EC6FF] bg-blue-50' : 'text-gray-400'}`}>
          <Users size={28} />
        </button>
        <button onClick={() => navigate('/about')} className={`p-2 rounded-xl ${isActive('/about') ? 'text-[#6EC6FF] bg-blue-50' : 'text-gray-400'}`}>
          <Info size={28} />
        </button>
        <button onClick={openWhatsApp} className="p-2 rounded-xl text-green-500">
          <MessageCircle size={28} />
        </button>
      </div>

      <div className="hidden md:flex flex-col w-64 bg-white shadow-xl h-screen sticky top-0 p-6 z-40">
        <div className="flex items-center gap-2 mb-10">
          <Mascot type="sun" className="w-10 h-10 border-2" />
          <div className="flex flex-col">
            <h2 className="font-bold text-xl text-gray-800 leading-tight">Divine Kids</h2>
            <span className="text-[10px] text-blue-500 font-bold tracking-widest uppercase">Academy</span>
          </div>
        </div>
        
        <nav className="space-y-4 flex-1">
          <NavItem icon={Home} label="Play Zone" active={isActive('/')} onClick={() => navigate('/')} />
          <NavItem icon={Type} label="Alphabet" active={isActive('/alphabet')} onClick={() => navigate('/alphabet')} />
          <NavItem icon={Music} label="Sing Along" active={isActive('/songs')} onClick={() => navigate('/songs')} />
          <NavItem icon={PieChart} label="Parent Dashboard" active={isActive('/dashboard')} onClick={() => navigate('/dashboard')} />
          <NavItem icon={Users} label="Hire Teachers" active={isActive('/teachers')} onClick={() => navigate('/teachers')} />
          <div className="pt-4 border-t mt-4">
             <button onClick={handleMusicToggle} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-gray-500 hover:bg-gray-50 transition-all">
                {isMusicOn ? <Volume2 size={20} className="text-purple-500" /> : <VolumeX size={20} />}
                {isMusicOn ? 'Music On' : 'Music Off'}
             </button>
             <NavItem icon={Lock} label="Premium Explorer" onClick={() => alert("Premium features coming soon!")} />
             <NavItem icon={Info} label="About Us" active={isActive('/about')} onClick={() => navigate('/about')} />
             <NavItem icon={MessageCircle} label="Support (WhatsApp)" onClick={openWhatsApp} />
          </div>
        </nav>

        <div className="text-[10px] text-gray-300 text-center uppercase tracking-widest font-bold">
          Divine Tech Co. Ltd.<br/>Jerusalem • Freetown
        </div>
      </div>
    </div>
  );
};

const NavItem: React.FC<{ icon: any, label: string, active?: boolean, onClick: () => void }> = ({ icon: Icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${active ? 'bg-[#6EC6FF] text-white shadow-lg shadow-blue-200' : 'text-gray-500 hover:bg-gray-50'}`}
  >
    <Icon size={20} />
    {label}
  </button>
);

const App: React.FC = () => {
  return (
    <HashRouter>
      <MainLayout />
    </HashRouter>
  );
};

export default App;
