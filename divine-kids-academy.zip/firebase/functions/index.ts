import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();
const db = admin.firestore();

// 1. On Session Complete: Aggregates scores
export const onSessionComplete = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'User must be logged in');

  const { studentId, subject, score, duration } = data;

  // Save raw record
  await db.collection('mastery_records').add({
    studentId,
    subject,
    score,
    timestamp: admin.firestore.FieldValue.serverTimestamp(),
    duration
  });

  // Update aggregated stats on student profile
  const studentRef = db.collection('students').doc(studentId);
  await db.runTransaction(async (t) => {
    const doc = await t.get(studentRef);
    if (!doc.exists) return;
    const currentStars = doc.data()?.stars || 0;
    
    // Award star logic (simple)
    t.update(studentRef, {
      stars: currentStars + (score > 80 ? 1 : 0),
      lastActive: admin.firestore.FieldValue.serverTimestamp()
    });
  });

  return { success: true };
});

// 2. Daily Login Streak
export const checkDailyLogin = functions.https.onCall(async (data, context) => {
   // Logic to check last login date vs today
   // If consecutive, increment streak
   // If gap > 1 day, reset streak
   return { streak: 5, reward: 'Star' };
});

// 3. Generate Certificate (Stub)
export const generateCertificate = functions.https.onCall(async (data, context) => {
  // In production: Use pdf-lib to generate PDF, upload to Storage, return download URL
  const { studentName, courseName } = data;
  return { 
    url: `https://storage.googleapis.com/divine-kids-academy/certs/stub-${studentName}.pdf`,
    message: "Certificate generated successfully" 
  };
});

// 4. Validate Subscription Stub
export const validateReceipt = functions.https.onCall(async (data, context) => {
  // Verify purchase token with Google Play / App Store API
  // Update user document with subscriptionStatus = 'premium'
  return { status: 'active', expiry: '2026-12-31' };
});
