
import { SpellingWord, TeacherProfile, Quest, GameType, Video } from './types';

// Brand Colors
export const COLORS = {
  skyBlue: '#6EC6FF',
  gardenGreen: '#4CAF50',
  sunYellow: '#FFD54F',
  friendlyPurple: '#9C27B0',
  textDark: '#333333',
  white: '#FFFFFF',
  danger: '#FF5252'
};

// Comprehensive Country Data for Auth
export const COUNTRY_DATA = [
  { name: "Afghanistan", code: "AF", dial: "+93", flag: "🇦🇫" },
  { name: "Albania", code: "AL", dial: "+355", flag: "🇦🇱" },
  { name: "Algeria", code: "DZ", dial: "+213", flag: "🇩🇿" },
  { name: "Andorra", code: "AD", dial: "+376", flag: "🇦🇩" },
  { name: "Angola", code: "AO", dial: "+244", flag: "🇦🇴" },
  { name: "Argentina", code: "AR", dial: "+54", flag: "🇦🇷" },
  { name: "Armenia", code: "AM", dial: "+374", flag: "🇦🇲" },
  { name: "Australia", code: "AU", dial: "+61", flag: "🇦🇺" },
  { name: "Austria", code: "AT", dial: "+43", flag: "🇦🇹" },
  { name: "Azerbaijan", code: "AZ", dial: "+994", flag: "🇦🇿" },
  { name: "Bahamas", code: "BS", dial: "+1-242", flag: "🇧🇸" },
  { name: "Bahrain", code: "BH", dial: "+973", flag: "🇧🇭" },
  { name: "Bangladesh", code: "BD", dial: "+880", flag: "🇧🇩" },
  { name: "Belgium", code: "BE", dial: "+32", flag: "🇧🇪" },
  { name: "Brazil", code: "BR", dial: "+55", flag: "🇧🇷" },
  { name: "Cameroon", code: "CM", dial: "+237", flag: "🇨🇲" },
  { name: "Canada", code: "CA", dial: "+1", flag: "🇨🇦" },
  { name: "China", code: "CN", dial: "+86", flag: "🇨🇳" },
  { name: "Egypt", code: "EG", dial: "+20", flag: "🇪🇬" },
  { name: "Ethiopia", code: "ET", dial: "+251", flag: "🇪🇹" },
  { name: "France", code: "FR", dial: "+33", flag: "🇫🇷" },
  { name: "Germany", code: "DE", dial: "+49", flag: "🇩🇪" },
  { name: "Ghana", code: "GH", dial: "+233", flag: "🇬🇭" },
  { name: "India", code: "IN", dial: "+91", flag: "🇮🇳" },
  { name: "Israel", code: "IL", dial: "+972", flag: "🇮🇱" },
  { name: "Italy", code: "IT", dial: "+39", flag: "🇮🇹" },
  { name: "Japan", code: "JP", dial: "+81", flag: "🇯🇵" },
  { name: "Kenya", code: "KE", dial: "+254", flag: "🇰🇪" },
  { name: "Lebanon", code: "LB", dial: "+961", flag: "🇱🇧" },
  { name: "Liberia", code: "LR", dial: "+231", flag: "🇱🇷" },
  { name: "Mexico", code: "MX", dial: "+52", flag: "🇲🇽" },
  { name: "Nigeria", code: "NG", dial: "+234", flag: "🇳🇬" },
  { name: "Norway", code: "NO", dial: "+47", flag: "🇳🇴" },
  { name: "Pakistan", code: "PK", dial: "+92", flag: "🇵🇰" },
  { name: "Russia", code: "RU", dial: "+7", flag: "🇷🇺" },
  { name: "Saudi Arabia", code: "SA", dial: "+966", flag: "🇸🇦" },
  { name: "Sierra Leone", code: "SL", dial: "+232", flag: "🇸🇱" },
  { name: "South Africa", code: "ZA", dial: "+27", flag: "🇿🇦" },
  { name: "Spain", code: "ES", dial: "+34", flag: "🇪🇸" },
  { name: "Switzerland", code: "CH", dial: "+41", flag: "🇨🇭" },
  { name: "Turkey", code: "TR", dial: "+90", flag: "🇹🇷" },
  { name: "UAE", code: "AE", dial: "+971", flag: "🇦🇪" },
  { name: "United Kingdom", code: "GB", dial: "+44", flag: "🇬🇧" },
  { name: "USA", code: "US", dial: "+1", flag: "🇺🇸" },
].sort((a, b) => a.name.localeCompare(b.name));

// Song Timings (in milliseconds from start)
export const ABC_SONG_TIMINGS = [
  { char: 'A', delay: 0 }, { char: 'B', delay: 700 }, { char: 'C', delay: 1400 }, 
  { char: 'D', delay: 2100 }, { char: 'E', delay: 2800 }, { char: 'F', delay: 3500 }, { char: 'G', delay: 4200 },
  { char: 'H', delay: 5600 }, { char: 'I', delay: 6300 }, { char: 'J', delay: 7000 }, 
  { char: 'K', delay: 7700 }, { char: 'L', delay: 8400 }, { char: 'M', delay: 8700 }, { char: 'N', delay: 9000 }, { char: 'O', delay: 9300 }, { char: 'P', delay: 9600 },
  { char: 'Q', delay: 11200 }, { char: 'R', delay: 11900 }, { char: 'S', delay: 12600 }, 
  { char: 'T', delay: 13300 }, { char: 'U', delay: 14000 }, { char: 'V', delay: 14700 },
  { char: 'W', delay: 16100 }, { char: 'X', delay: 16800 }, { char: 'Y', delay: 17500 }, { char: 'Z', delay: 18500 }
];

export const COUNTING_SONG_TIMINGS = Array.from({length: 20}, (_, i) => ({
    num: i + 1,
    delay: i * 1200 // Steady rhythmic march, 1.2s per number
}));

// Seed Data: Spelling Words
export const SPELLING_WORDS: SpellingWord[] = [
  { id: '5', word: 'APPLE', image: '🍎', category: 'food', sentence: 'The red apple is crunchy and sweet.' },
  { id: '9', word: 'BALL', image: '⚽', category: 'objects', sentence: 'I love to kick the soccer ball.' },
  { id: '1', word: 'CAT', image: '🐱', category: 'animals', sentence: 'The cute cat says meow.' },
  { id: '2', word: 'DOG', image: '🐶', category: 'animals', sentence: 'The happy dog wags its tail.' },
  { id: '21', word: 'ELEPHANT', image: '🐘', category: 'animals', sentence: 'The big elephant has a long trunk.' },
  { id: '6', word: 'FISH', image: '🐠', category: 'animals', sentence: 'The little fish swims in the water.' },
  { id: '25', word: 'GRAPES', image: '🍇', category: 'food', sentence: 'The purple grapes are sweet and juicy.' },
  { id: '26', word: 'HAT', image: '🎩', category: 'objects', sentence: 'I wear a hat on my head.' },
  { id: '27', word: 'ICE CREAM', image: '🍦', category: 'food', sentence: 'Ice cream is a cold and yummy treat.' },
  { id: '28', word: 'JELLYFISH', image: '🪼', category: 'animals', sentence: 'The jellyfish floats in the deep blue sea.' },
  { id: '29', word: 'KITE', image: '🪁', category: 'objects', sentence: 'The kite flies high in the wind.' },
  { id: '10', word: 'LION', image: '🦁', category: 'animals', sentence: 'The lion is the king of the jungle.' },
  { id: '16', word: 'MONKEY', image: '🐵', category: 'animals', sentence: 'The monkey climbs the tall tree.' },
  { id: '30', word: 'NEST', image: '🪺', category: 'objects', sentence: 'The bird builds a nest for its eggs.' },
  { id: '22', word: 'OWL', image: '🦉', category: 'animals', sentence: 'The wise owl stays awake at night.' },
  { id: '13', word: 'PIG', image: '🐷', category: 'animals', sentence: 'The pink pig likes to roll in mud.' },
  { id: '31', word: 'QUEEN', image: '👑', category: 'objects', sentence: 'The queen wears a beautiful gold crown.' },
  { id: '18', word: 'RABBIT', image: '🐰', category: 'animals', sentence: 'The white rabbit hops very fast.' },
  { id: '3', word: 'SUN', image: '☀️', category: 'objects', sentence: 'The sun shines bright in the sky.' },
  { id: '11', word: 'TIGER', image: '🐯', category: 'animals', sentence: 'The tiger has orange and black stripes.' },
  { id: '32', word: 'UMBRELLA', image: '☂️', category: 'objects', sentence: 'An umbrella keeps you dry in the rain.' },
  { id: '33', word: 'VIOLIN', image: '🎻', category: 'objects', sentence: 'The violin makes beautiful music.' },
  { id: '24', word: 'WHALE', image: '🐳', category: 'animals', sentence: 'The giant whale swims in the deep ocean.' },
  { id: '34', word: 'XYLOPHONE', image: '🎹', category: 'objects', sentence: 'We play music on the rainbow xylophone.' },
  { id: '35', word: 'YOYO', image: '🪀', category: 'objects', sentence: 'The yoyo goes down and up again.' },
  { id: '36', word: 'ZEBRA', image: '🦓', category: 'animals', sentence: 'The zebra has black and white stripes.' },
];

export const MOCK_TEACHERS: TeacherProfile[] = [
  {
    id: 't1',
    name: 'Ms. Sarah Johnson',
    bio: 'Certified Kindergarten teacher with 10 years experience.',
    subjects: ['Phonics', 'Math'],
    hourlyRate: 25,
    isVerified: true,
    availability: 'Mon-Fri 9AM-12PM',
    rating: 4.9,
    reviews: 42,
    location: 'Online / Freetown'
  },
  {
    id: 't2',
    name: 'Mr. David Okafor',
    bio: 'Specialist in early childhood development and art.',
    subjects: ['Art', 'Reading'],
    hourlyRate: 20,
    isVerified: true,
    availability: 'Weekends',
    rating: 4.7,
    reviews: 28,
    location: 'Lagos'
  }
];

export const DAILY_QUESTS: Quest[] = [
  { id: 'q1', title: 'Spell 3 Words', targetCount: 3, rewardStars: 5, type: GameType.SPELLING },
  { id: 'q2', title: 'Solve 5 Math Problems', targetCount: 5, rewardStars: 5, type: GameType.MATH },
  { id: 'q3', title: 'Find 3 Animals', targetCount: 3, rewardStars: 3, type: GameType.ANIMALS }
];

export const SUPPORT_NUMBERS = {
  SIERRA_LEONE: '+23234547720',
  NIGERIA: '+2348131580474'
};

export const VIDEOS: Video[] = [
  { id: 'a1', youtubeId: 'b051ktudQDQ', title: 'ABCs & 123s Phonics', category: 'Alphabet', type: 'video', duration: '40:00' },
  { id: 'a2', youtubeId: 'dTQVzcwhsSc', title: 'ABC Colors Shapes & Numbers', category: 'Alphabet', type: 'video', duration: '55:00' },
  { id: 'm1', youtubeId: 'Be4j6lJpFTQ', title: 'Counting to 20 Song', category: 'Math', type: 'video', duration: '2:15' },
  { id: 's1', youtubeId: 'JcxTM7knO80', title: 'Crash Course Kids Intro', category: 'Science', type: 'video', duration: '3:00', isPremium: true },
];
