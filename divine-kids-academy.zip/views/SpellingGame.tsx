import React, { useState, useEffect } from 'react';
import { Card, BubbleButton, Mascot } from '../components/UIComponents';
import { SPELLING_WORDS } from '../constants';
import { Shuffle, RefreshCcw, Star, Volume2, ArrowLeft, LayoutGrid, Type } from 'lucide-react';
import { SpellingWord } from '../types';
import { speak } from '../utils/soundUtils';

type GameMode = 'menu' | 'alphabet' | 'spelling';

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('');

export const SpellingGame: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const [mode, setMode] = useState<GameMode>('menu');
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [scrambledLetters, setScrambledLetters] = useState<{id: number, char: string}[]>([]);
  const [placedLetters, setPlacedLetters] = useState<(string | null)[]>([]);
  const [isCorrect, setIsCorrect] = useState(false);
  const [score, setScore] = useState(0);

  // Alphabet State
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);

  const currentWordData = SPELLING_WORDS[currentWordIndex];

  useEffect(() => {
    if (mode === 'spelling') {
       loadWord(currentWordIndex);
    }
  }, [currentWordIndex, mode]);

  const loadWord = (index: number) => {
    const word = SPELLING_WORDS[index].word;
    const letters = word.split('').map((char, i) => ({ id: i, char }));
    // Shuffle
    setScrambledLetters([...letters].sort(() => Math.random() - 0.5));
    setPlacedLetters(new Array(word.length).fill(null));
    setIsCorrect(false);
  };

  const playWord = () => {
     speak(currentWordData.word.toLowerCase());
  };

  const handleLetterClick = (char: string, index: number) => {
    if (isCorrect) return;

    // Find first empty slot
    const emptySlotIndex = placedLetters.findIndex(l => l === null);
    if (emptySlotIndex !== -1) {
      const newPlaced = [...placedLetters];
      newPlaced[emptySlotIndex] = char;
      setPlacedLetters(newPlaced);

      // Remove from scrambled pool (visual only, we hide it)
      const newScrambled = [...scrambledLetters];
      newScrambled.splice(index, 1);
      setScrambledLetters(newScrambled);
      
      speak(char.toLowerCase());
      checkWin(newPlaced);
    }
  };

  const handleSlotClick = (index: number) => {
    if (isCorrect || !placedLetters[index]) return;
    
    // Return letter to pool
    const char = placedLetters[index]!;
    const newPlaced = [...placedLetters];
    newPlaced[index] = null;
    setPlacedLetters(newPlaced);

    setScrambledLetters(prev => [...prev, { id: Math.random(), char }]);
  };

  const checkWin = (currentPlaced: (string | null)[]) => {
    const attemptedWord = currentPlaced.join('');
    if (attemptedWord === currentWordData.word) {
      setIsCorrect(true);
      setScore(s => s + 10);
      const audio = new Audio('https://codeskulptor-demos.commondatastorage.googleapis.com/pang/arrow.mp3'); // Success sound
      audio.play().catch(() => {});
      setTimeout(() => playWord(), 500);
    }
  };

  const nextLevel = () => {
    if (currentWordIndex < SPELLING_WORDS.length - 1) {
      setCurrentWordIndex(prev => prev + 1);
    } else {
      setCurrentWordIndex(0);
    }
  };

  const handleAlphabetClick = (char: string) => {
      setSelectedLetter(char);
      const example = SPELLING_WORDS.find(w => w.word.startsWith(char));
      if (example) {
          speak(`${char} is for ${example.word}`);
      } else {
          speak(char);
      }
  };

  return (
    <div className="flex flex-col h-full max-w-2xl mx-auto p-4 relative">
      <div className="flex justify-between items-center mb-6">
        <BubbleButton variant="secondary" size="sm" onClick={mode === 'menu' ? onExit : () => setMode('menu')} icon={ArrowLeft}>
            {mode === 'menu' ? 'Back' : 'Menu'}
        </BubbleButton>
        <div className="flex items-center gap-2 bg-yellow-100 px-4 py-2 rounded-full">
          <Star className="text-yellow-500 fill-yellow-500" />
          <span className="font-bold text-yellow-800">{score} Stars</span>
        </div>
      </div>

      {/* MENU */}
      {mode === 'menu' && (
          <div className="grid grid-cols-1 gap-6 animate-fade-in">
              <Card className="bg-blue-50 border-blue-200 text-center py-8">
                  <h2 className="text-3xl font-bold text-blue-700 mb-2">ABC & Spelling</h2>
                  <p className="text-gray-500">Learn letters and build words!</p>
              </Card>

              <div onClick={() => setMode('alphabet')} className="bg-white p-6 rounded-3xl flex items-center gap-6 cursor-pointer hover:shadow-xl transition-all border-4 border-purple-100 group">
                  <div className="bg-purple-100 p-4 rounded-2xl group-hover:scale-110 transition-transform">
                      <LayoutGrid size={40} className="text-purple-500" />
                  </div>
                  <div>
                      <h3 className="text-2xl font-bold text-gray-800">Learn ABCs</h3>
                      <p className="text-gray-500">Explore the alphabet from A to Z</p>
                  </div>
              </div>

              <div onClick={() => setMode('spelling')} className="bg-white p-6 rounded-3xl flex items-center gap-6 cursor-pointer hover:shadow-xl transition-all border-4 border-yellow-100 group">
                  <div className="bg-yellow-100 p-4 rounded-2xl group-hover:scale-110 transition-transform">
                      <Type size={40} className="text-yellow-600" />
                  </div>
                  <div>
                      <h3 className="text-2xl font-bold text-gray-800">Spelling Bee</h3>
                      <p className="text-gray-500">Arrange letters to make words</p>
                  </div>
              </div>
          </div>
      )}

      {/* ALPHABET MODE */}
      {mode === 'alphabet' && (
          <div className="flex-1 animate-fade-in">
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
                  {ALPHABET.map(char => (
                      <button 
                        key={char}
                        onClick={() => handleAlphabetClick(char)}
                        className={`aspect-square rounded-xl flex items-center justify-center text-3xl font-black shadow-sm transition-all ${selectedLetter === char ? 'bg-[#6EC6FF] text-white scale-110 ring-4 ring-blue-200' : 'bg-white text-gray-700 hover:bg-gray-50'}`}
                      >
                          {char}
                      </button>
                  ))}
              </div>
              
              {/* Preview Box */}
              {selectedLetter && (
                 <div className="mt-6 bg-white rounded-3xl p-6 shadow-xl border-4 border-blue-100 text-center animate-bounce-in">
                     <div className="text-8xl font-black text-blue-500 mb-2">{selectedLetter}</div>
                     {SPELLING_WORDS.find(w => w.word.startsWith(selectedLetter)) && (
                         <div className="flex flex-col items-center">
                             <div className="text-6xl mb-2">{SPELLING_WORDS.find(w => w.word.startsWith(selectedLetter))?.image}</div>
                             <div className="text-xl font-bold text-gray-600">{SPELLING_WORDS.find(w => w.word.startsWith(selectedLetter))?.word}</div>
                         </div>
                     )}
                 </div>
              )}
          </div>
      )}

      {/* SPELLING MODE */}
      {mode === 'spelling' && (
        <Card className="flex-1 flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-b from-blue-50 to-white animate-fade-in">
            {isCorrect && (
            <div className="absolute inset-0 z-10 bg-black/10 flex items-center justify-center backdrop-blur-[2px] animate-fade-in">
                <div className="bg-white p-8 rounded-3xl shadow-2xl text-center animate-bounce-in">
                <h2 className="text-4xl font-bold text-[#4CAF50] mb-4">Great Job!</h2>
                <div className="text-6xl mb-6">⭐</div>
                <BubbleButton onClick={nextLevel} variant="success" size="lg" icon={Shuffle}>
                    Next Word
                </BubbleButton>
                </div>
            </div>
            )}

            <div className="relative mb-8 group">
            <div 
                className="text-8xl animate-bounce cursor-pointer select-none" 
                onClick={playWord}
            >
                {currentWordData.image}
            </div>
            <BubbleButton 
                onClick={(e) => { e.stopPropagation(); playWord(); }}
                className="absolute -bottom-2 -right-2 shadow-lg z-10 rounded-full w-12 h-12 !px-0 flex items-center justify-center" 
                variant="primary" 
                size="md" 
                aria-label="Listen to word"
            >
                <Volume2 size={24} />
            </BubbleButton>
            </div>

            {/* Target Slots - Responsive wrap */}
            <div className="flex flex-wrap justify-center gap-2 mb-12 max-w-full">
            {placedLetters.map((char, i) => (
                <div 
                key={i} 
                onClick={() => handleSlotClick(i)}
                className={`w-12 h-12 sm:w-16 sm:h-16 md:w-20 md:h-20 border-b-4 ${char ? 'border-[#6EC6FF] bg-blue-50' : 'border-gray-300 bg-gray-100'} rounded-xl flex items-center justify-center text-2xl sm:text-3xl font-bold text-gray-700 cursor-pointer transition-colors`}
                >
                {char}
                </div>
            ))}
            </div>

            {/* Source Letters */}
            <div className="flex flex-wrap gap-3 justify-center">
            {scrambledLetters.map((item, i) => (
                <button
                key={item.id}
                onClick={() => handleLetterClick(item.char, i)}
                className="w-14 h-14 sm:w-16 sm:h-16 bg-[#FFD54F] border-b-4 border-yellow-600 rounded-2xl shadow-md active:translate-y-1 active:shadow-none flex items-center justify-center text-2xl sm:text-3xl font-bold text-yellow-900 transition-transform hover:-translate-y-1"
                >
                {item.char}
                </button>
            ))}
            </div>
        </Card>
      )}
      
      {mode !== 'menu' && (
        <div className="mt-4 flex justify-center">
            <Mascot type="elephant" className="w-16 h-16" />
        </div>
      )}
    </div>
  );
};