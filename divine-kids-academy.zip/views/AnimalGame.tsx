import React, { useState, useEffect, useRef } from 'react';
import { Card, BubbleButton, Mascot } from '../components/UIComponents';
import { SPELLING_WORDS } from '../constants';
import { SpellingWord } from '../types';
import { ArrowLeft, Star, Shuffle, CheckCircle, XCircle, Volume2, Settings, X, Play, Mic, MicOff, Type, Image as ImageIcon, Pause, RefreshCcw } from 'lucide-react';
import { speak } from '../utils/soundUtils';

const styles = (
  <style>{`
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-6px); }
      75% { transform: translateX(6px); }
    }
    .animate-shake {
      animation: shake 0.4s ease-in-out;
    }
    @keyframes pop {
      0% { transform: scale(1); }
      40% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
    .animate-pop {
      animation: pop 0.3s ease-out;
    }
  `}</style>
);

export const AnimalGame: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const [score, setScore] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // Game Mode State
  const [gameMode, setGameMode] = useState<'read-word' | 'first-letter'>('read-word');

  const [options, setOptions] = useState<any[]>([]);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  
  // Voice Recognition
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Filter only animals from the word list
  const animalWords = SPELLING_WORDS.filter(w => w.category === 'animals');
  const currentAnimal = animalWords[currentIndex % animalWords.length];

  useEffect(() => {
    generateOptions();
  }, [currentIndex, gameMode]);

  const generateOptions = () => {
    setSelectedOptionId(null);
    setIsCorrect(null);

    if (gameMode === 'read-word') {
        const correct = currentAnimal;
        const others = animalWords.filter(w => w.id !== correct.id);
        const shuffledOthers = others.sort(() => 0.5 - Math.random()).slice(0, 2);
        const allOptions = [correct, ...shuffledOthers].sort(() => 0.5 - Math.random());
        setOptions(allOptions);
    } else {
        // First Letter Mode
        const correctLetter = currentAnimal.word.charAt(0).toUpperCase();
        const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const otherLetters: string[] = [];
        
        while(otherLetters.length < 2) {
            const l = alphabet[Math.floor(Math.random() * alphabet.length)];
            if (l !== correctLetter && !otherLetters.includes(l)) {
                otherLetters.push(l);
            }
        }
        
        const allLetters = [correctLetter, ...otherLetters].sort(() => 0.5 - Math.random());
        setOptions(allLetters);
    }
  };

  const playAnimalName = () => {
    speak(currentAnimal.word);
  };

  const handleOptionClick = (option: any) => {
    if (selectedOptionId) return; // Prevent multiple clicks

    const isLetterMode = gameMode === 'first-letter';
    // Guard: Ensure option matches mode expectation
    if (isLetterMode && (typeof option !== 'string')) return;
    if (!isLetterMode && (typeof option !== 'object')) return;

    const optionValue = isLetterMode ? option : (option as SpellingWord).id;
    const correctValue = isLetterMode ? currentAnimal.word.charAt(0).toUpperCase() : currentAnimal.id;

    setSelectedOptionId(optionValue);
    const correct = optionValue === correctValue;
    setIsCorrect(correct);

    if (correct) {
      setScore(s => s + 10);
      const audio = new Audio('https://codeskulptor-demos.commondatastorage.googleapis.com/pang/arrow.mp3');
      audio.play().catch(() => {});
      
      if (isLetterMode) {
          speak(`${currentAnimal.word.charAt(0)} is for ${currentAnimal.word}`);
      } else {
          setTimeout(() => playAnimalName(), 500);
      }
    } else {
       if ('vibrate' in navigator) navigator.vibrate(200);
       speak("Oops, try again!");
    }
  };

  const handleRetry = () => {
    setSelectedOptionId(null);
    setIsCorrect(null);
    playAnimalName();
  };

  // Voice Recognition
  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice recognition is not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript.toLowerCase();
      handleVoiceInput(transcript);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleVoiceInput = (input: string) => {
      // Find the option that matches the spoken input
      if (gameMode === 'read-word') {
          // Input: "Cat", "Dog"
          // Check if options are objects before filtering
          const matchedOption = options.find((opt: any) => {
              if (typeof opt !== 'object' || !opt.word) return false;
              return opt.word.toLowerCase() === input || input.includes(opt.word.toLowerCase());
          });
          
          if (matchedOption) {
              handleOptionClick(matchedOption);
          } else {
              speak("Try again");
          }
      } else {
          // Input: "A", "B"
          const firstChar = input.charAt(0).toUpperCase();
          const matchedOption = options.find((opt: any) => typeof opt === 'string' && opt === firstChar);
          if (matchedOption) {
              handleOptionClick(matchedOption);
          }
      }
  };

  const nextLevel = () => {
    setCurrentIndex(prev => (prev + 1) % animalWords.length);
  };

  const isLetterMode = gameMode === 'first-letter';

  return (
    <div className="flex flex-col h-full max-w-2xl mx-auto p-4 relative">
      {styles}
      
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <BubbleButton variant="secondary" size="sm" onClick={onExit} icon={ArrowLeft}>Back</BubbleButton>
        
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-yellow-100 px-4 py-2 rounded-full">
            <Star className="text-yellow-500 fill-yellow-500" />
            <span className="font-bold text-yellow-800">{score}</span>
          </div>
        </div>
      </div>

      {/* Mode Toggle */}
      <div className="flex justify-center mb-6">
          <div className="bg-white p-1 rounded-full border-2 border-blue-100 shadow-sm flex">
              <button 
                onClick={() => setGameMode('read-word')}
                className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${!isLetterMode ? 'bg-[#6EC6FF] text-white font-bold shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                 <Type size={16} /> Read Word
              </button>
              <button 
                onClick={() => setGameMode('first-letter')}
                className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${isLetterMode ? 'bg-[#6EC6FF] text-white font-bold shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                 <ImageIcon size={16} /> First Letter
              </button>
          </div>
      </div>

      {/* Game Card */}
      <Card className="flex-1 flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-b from-[#FFF9C4] to-white border-yellow-200">
        
        {/* Success Overlay */}
        {isCorrect === true && (
          <div className="absolute inset-0 z-20 bg-white/90 flex items-center justify-center backdrop-blur-sm animate-fade-in rounded-3xl">
             <div className="text-center animate-bounce-in p-6">
               <div className="text-8xl mb-4">🎉</div>
               <h2 className="text-4xl font-bold text-[#4CAF50] mb-2">Correct!</h2>
               <p className="text-xl text-gray-500 mb-8">
                   {isLetterMode ? `${currentAnimal.word.charAt(0)} is for ${currentAnimal.word}` : `It is a ${currentAnimal.word}!`}
               </p>
               <BubbleButton onClick={nextLevel} variant="success" size="lg" icon={Shuffle} className="mx-auto shadow-xl">
                 Next Animal
               </BubbleButton>
             </div>
          </div>
        )}

        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-[#5D4037] mb-2">
             {isLetterMode ? 'What starts with...?' : 'Which one is...'}
          </h2>
          <div className="w-16 h-2 bg-yellow-200 mx-auto rounded-full"></div>
        </div>
        
        {/* Main Display */}
        <div 
          onClick={playAnimalName}
          className="relative group mb-10 drop-shadow-sm hover:scale-105 transition-transform duration-300 cursor-pointer select-none border-4 border-dashed border-[#5D4037]/20 p-8 rounded-3xl bg-white/50"
        >
            {isLetterMode ? (
                <div className="text-[8rem] leading-none filter drop-shadow-md">{currentAnimal.image}</div>
            ) : (
                <div className="text-6xl md:text-8xl font-black text-[#5D4037]">{currentAnimal.word}</div>
            )}
            
            <div className="absolute -bottom-4 -right-4 bg-white rounded-full p-3 shadow-lg border-2 border-gray-100 hover:bg-gray-50 transition-colors">
              <Volume2 size={32} className="text-[#5D4037]" />
            </div>
        </div>

        {/* Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-lg z-10">
          {options.map((opt) => {
             // Type Guard to prevent Error #31
             const isObject = typeof opt === 'object' && opt !== null && 'id' in opt;
             
             // If mode is letter but we have objects, or vice versa, skip rendering
             if (isLetterMode && isObject) return null;
             if (!isLetterMode && !isObject) return null;

             const val = isLetterMode ? opt : (opt as SpellingWord).id;
             const isSelected = selectedOptionId === val;
             const isCorrectOption = isLetterMode ? val === currentAnimal.word.charAt(0).toUpperCase() : val === currentAnimal.id;
             
             // Animation Logic
             let animClass = '';
             if (isSelected) {
                 animClass = isCorrectOption ? 'animate-pop ring-4 ring-green-300' : 'animate-shake ring-4 ring-red-300';
             }

             // Visual variant
             let variant: 'primary' | 'success' | 'danger' | 'warning' = 'warning';
             if (selectedOptionId) {
                 if (isCorrectOption) variant = 'success';
                 else if (isSelected && !isCorrectOption) variant = 'danger';
                 else variant = 'warning';
             }
             
             return (
               <BubbleButton 
                 key={val}
                 onClick={() => handleOptionClick(opt)}
                 variant={variant}
                 fullWidth
                 className={`py-6 md:py-8 transition-all relative ${animClass} ${selectedOptionId && !isSelected && !isCorrectOption ? 'opacity-40' : ''}`}
               >
                 {isLetterMode ? (
                     <span className="text-6xl font-black">{opt}</span>
                 ) : (
                     <span className="flex-1 text-center text-7xl md:text-8xl leading-none filter drop-shadow-md">{(opt as SpellingWord).image}</span>
                 )}
                 
                 {selectedOptionId && isCorrectOption && <CheckCircle className="absolute top-2 right-2" />}
                 {selectedOptionId && isSelected && !isCorrectOption && <XCircle className="absolute top-2 right-2" />}
               </BubbleButton>
             )
          })}
        </div>

        {/* Mic Button or Retry */}
        <div className="mt-8 flex justify-center w-full">
            {isCorrect === false ? (
                 <div className="animate-fade-in flex flex-col items-center w-full">
                     <p className="text-red-500 font-bold mb-3 text-lg animate-pulse">Oops! Not quite.</p>
                     <BubbleButton 
                        onClick={handleRetry} 
                        variant="primary" 
                        size="lg"
                        icon={RefreshCcw}
                        className="animate-bounce shadow-xl ring-4 ring-blue-100"
                     >
                        Retry & Listen Again
                     </BubbleButton>
                  </div>
            ) : (
                <div className="flex flex-col items-center">
                    <button 
                        onClick={toggleListening}
                        disabled={selectedOptionId !== null} 
                        className={`p-6 rounded-full shadow-xl transition-all border-4 ${isListening ? 'bg-red-500 border-red-200 animate-pulse text-white' : 'bg-white border-blue-200 text-blue-500 hover:scale-110'} ${selectedOptionId !== null ? 'opacity-40 grayscale cursor-not-allowed' : ''}`}
                    >
                        {isListening ? <MicOff size={32} /> : <Mic size={32} />}
                    </button>
                    <p className="text-center text-xs text-gray-400 mt-2 font-bold uppercase tracking-wider">
                        {isListening ? 'Listening...' : 'Tap to Speak'}
                    </p>
                </div>
            )}
        </div>

      </Card>
    </div>
  );
};