import React from 'react';
import { Card, BubbleButton, Mascot } from '../components/UIComponents';
import { ArrowLeft, Heart, Shield, GraduationCap, MapPin } from 'lucide-react';

export const AboutView: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  return (
    <div className="p-4 max-w-4xl mx-auto pb-24 animate-fade-in">
       <div className="flex items-center mb-6">
          <BubbleButton variant="secondary" size="sm" onClick={onExit} icon={ArrowLeft}>Back</BubbleButton>
          <h1 className="text-2xl font-bold text-gray-800 ml-4">About Us</h1>
       </div>
       
       <Card className="mb-6 text-center border-purple-100 bg-gradient-to-b from-purple-50 to-white">
          <Mascot type="sun" className="mx-auto mb-4" />
          <h2 className="text-3xl font-extrabold text-[#9C27B0] mb-2 font-[Fredoka]">Divine Kids Academy</h2>
          <p className="text-gray-600 text-lg font-medium">Empowering the next generation of learners.</p>
       </Card>

       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-blue-50 border-blue-200 hover:scale-[1.02] transition-transform">
             <div className="flex items-center gap-3 mb-2">
                <div className="p-3 bg-blue-100 rounded-xl text-blue-600 shadow-sm"><Shield size={24} /></div>
                <h3 className="text-xl font-bold text-gray-800">Safe & Secure</h3>
             </div>
             <p className="text-gray-600">A COPPA-compliant environment where kids can explore safely without ads or data tracking. Your child's safety is our priority.</p>
          </Card>

          <Card className="bg-green-50 border-green-200 hover:scale-[1.02] transition-transform">
             <div className="flex items-center gap-3 mb-2">
                <div className="p-3 bg-green-100 rounded-xl text-green-600 shadow-sm"><GraduationCap size={24} /></div>
                <h3 className="text-xl font-bold text-gray-800">Expert Curriculum</h3>
             </div>
             <p className="text-gray-600">Designed by early childhood experts to make learning math, reading, spelling, and science fun and engaging.</p>
          </Card>

           <Card className="bg-yellow-50 border-yellow-200 hover:scale-[1.02] transition-transform">
             <div className="flex items-center gap-3 mb-2">
                <div className="p-3 bg-yellow-100 rounded-xl text-yellow-600 shadow-sm"><Heart size={24} /></div>
                <h3 className="text-xl font-bold text-gray-800">Made with Love</h3>
             </div>
             <p className="text-gray-600">Created by <span className="font-bold">Divine Tech Company Limited</span>. We are dedicated to providing quality education technology.</p>
          </Card>

          <Card className="bg-orange-50 border-orange-200 hover:scale-[1.02] transition-transform">
             <div className="flex items-center gap-3 mb-2">
                <div className="p-3 bg-orange-100 rounded-xl text-orange-600 shadow-sm"><MapPin size={24} /></div>
                <h3 className="text-xl font-bold text-gray-800">Our Roots</h3>
             </div>
             <p className="text-gray-600">Proudly based in Sierra Leone, building solutions for children across Africa and the world.</p>
          </Card>
       </div>
       
       <div className="mt-12 text-center">
          <p className="text-gray-400 text-sm font-bold">Version 1.0.0</p>
          <p className="text-gray-400 text-xs mt-1">© 2026 Divine Tech Co. Ltd.</p>
       </div>
    </div>
  );
};