
import React, { useState, useEffect, useRef } from 'react';
import { Card, BubbleButton, Mascot } from '../components/UIComponents';
import { ArrowLeft, Play, Pause, Music, AlertCircle } from 'lucide-react';
import { speak, playInstrumental, stopInstrumental } from '../utils/soundUtils';
import { ABC_SONG_TIMINGS, COUNTING_SONG_TIMINGS } from '../constants';

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('');
// Ensure numbers 1-20 are generated to match the timings
const NUMBERS = Array.from({ length: 20 }, (_, i) => i + 1);

type SongMode = 'alphabet' | 'counting';

export const SongsView: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const [mode, setMode] = useState<SongMode>('alphabet');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentItem, setCurrentItem] = useState<string | number | null>(null);
  const [audioError, setAudioError] = useState<string | null>(null);
  
  // Timers
  const timeoutsRef = useRef<number[]>([]);

  useEffect(() => {
    // Check for speech synthesis support
    if (!('speechSynthesis' in window)) {
        setAudioError("Your device doesn't support singing voices.");
    }
    return () => stopSong();
  }, []);

  const stopSong = () => {
    timeoutsRef.current.forEach(t => clearTimeout(t));
    timeoutsRef.current = [];
    
    stopInstrumental(); // Stop the backing track
    window.speechSynthesis.cancel();
    
    setIsPlaying(false);
    setCurrentItem(null);
  };

  const startSong = () => {
    stopSong(); // Clean up previous
    setIsPlaying(true);
    setAudioError(null);
    
    // 1. Play Instrumental Track
    playInstrumental(mode === 'alphabet' ? 'abc' : 'count', (errorMsg) => {
        setAudioError(errorMsg);
        // We continue anyway with voice only (A cappella)
    });

    // 2. Schedule Lyrics & Highlighting
    if (mode === 'alphabet') {
        const startOffset = 2000; // Intro time for instrumental

        // Intro Voice
        speak("Let's sing the A B C song!");
        
        // Schedule Letters
        ABC_SONG_TIMINGS.forEach(({ char, delay }) => {
            const t = window.setTimeout(() => {
                setCurrentItem(char);
                speak(char, undefined, 1.1, 1.5); // Slightly faster, higher pitch for song
            }, startOffset + delay);
            timeoutsRef.current.push(t);
        });

        // Outro
        const finishTime = startOffset + ABC_SONG_TIMINGS[ABC_SONG_TIMINGS.length - 1].delay + 1500;
        const tEnd = window.setTimeout(() => {
             setCurrentItem(null);
             speak("Now I know my ABCs, next time won't you sing with me!");
             setTimeout(() => setIsPlaying(false), 4000);
        }, finishTime);
        timeoutsRef.current.push(tEnd);

    } else {
        const startOffset = 1500; // Intro time

        // Intro Voice
        speak("Ready? Let's count!");

        // Schedule Numbers
        COUNTING_SONG_TIMINGS.forEach(({ num, delay }) => {
            const t = window.setTimeout(() => {
                setCurrentItem(num);
                speak(num.toString(), undefined, 1.2, 1.4); // Energetic
            }, startOffset + delay);
            timeoutsRef.current.push(t);
        });

        // Outro
        const finishTime = startOffset + COUNTING_SONG_TIMINGS[COUNTING_SONG_TIMINGS.length - 1].delay + 1500;
        const tEnd = window.setTimeout(() => {
            setCurrentItem(null);
            speak("Great counting! You are a star!");
            setTimeout(() => setIsPlaying(false), 3000);
        }, finishTime);
        timeoutsRef.current.push(tEnd);
    }
  };

  return (
    <div className="p-4 max-w-4xl mx-auto pb-24 h-full flex flex-col">
      <div className="flex items-center mb-6 justify-between">
        <div className="flex items-center">
             <BubbleButton variant="secondary" size="sm" onClick={onExit} icon={ArrowLeft}>Back</BubbleButton>
             <h1 className="text-2xl font-bold text-gray-800 ml-4">Sing-Along</h1>
        </div>
        <div className="bg-purple-100 p-2 rounded-full">
            <Music className="text-purple-500 animate-bounce" />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 justify-center mb-6">
        <button
          onClick={() => { stopSong(); setMode('alphabet'); }}
          className={`px-6 py-3 rounded-full font-bold text-lg transition-all ${
            mode === 'alphabet' 
              ? 'bg-[#6EC6FF] text-white shadow-lg scale-105' 
              : 'bg-white text-gray-500 hover:bg-gray-50'
          }`}
        >
          ABC Song
        </button>
        <button
          onClick={() => { stopSong(); setMode('counting'); }}
          className={`px-6 py-3 rounded-full font-bold text-lg transition-all ${
            mode === 'counting' 
              ? 'bg-[#4CAF50] text-white shadow-lg scale-105' 
              : 'bg-white text-gray-500 hover:bg-gray-50'
          }`}
        >
          123 Song
        </button>
      </div>

      <Card className={`flex-1 flex flex-col relative overflow-hidden transition-colors duration-500 ${mode === 'alphabet' ? 'bg-blue-50 border-blue-200' : 'bg-green-50 border-green-200'}`}>
         
         <div className="text-center mb-6 pt-4 relative z-10">
             <Mascot type={mode === 'alphabet' ? 'sun' : 'elephant'} className="mx-auto w-24 h-24 mb-4" />
             <h2 className="text-3xl font-bold text-gray-700 font-[Fredoka]">
               {mode === 'alphabet' ? 'Sing the Alphabet!' : 'Count to 20!'}
             </h2>
         </div>

         {/* Audio Error Banner */}
         {audioError && (
             <div className="bg-red-50 border border-red-200 text-red-600 p-3 rounded-xl mb-4 flex items-center gap-2 animate-fade-in mx-4 relative z-10">
                 <AlertCircle size={20} />
                 <span className="text-sm font-bold">{audioError}</span>
             </div>
         )}

         {/* Grid Content */}
         <div className="flex-1 overflow-y-auto px-4 pb-20 relative z-10">
            <div className={`grid gap-3 ${mode === 'alphabet' ? 'grid-cols-4 sm:grid-cols-6' : 'grid-cols-4 sm:grid-cols-5'}`}>
              {(mode === 'alphabet' ? ALPHABET : NUMBERS).map((item) => {
                  const isActive = currentItem === item;
                  return (
                    <div 
                        key={item}
                        className={`aspect-square rounded-2xl flex items-center justify-center text-2xl sm:text-3xl font-black transition-all duration-300 transform ${
                            isActive 
                                ? 'bg-white scale-125 shadow-2xl text-[#6EC6FF] border-4 border-[#6EC6FF] z-20' 
                                : 'bg-white/50 text-gray-400 scale-100'
                        }`}
                    >
                        {item}
                    </div>
                  );
              })}
            </div>
         </div>

         {/* Play Controls - Fixed Bottom */}
         <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-white via-white to-transparent z-30 flex justify-center pt-12">
             <BubbleButton 
                onClick={isPlaying ? stopSong : startSong} 
                variant={isPlaying ? "danger" : "success"} 
                size="xl"
                className="shadow-2xl animate-bounce-in"
                icon={isPlaying ? Pause : Play}
             >
                 {isPlaying ? 'Stop Singing' : 'Start Singing!'}
             </BubbleButton>
         </div>

      </Card>
    </div>
  );
};
