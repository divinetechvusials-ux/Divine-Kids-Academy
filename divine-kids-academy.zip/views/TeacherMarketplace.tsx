import React from 'react';
import { Card, BubbleButton } from '../components/UIComponents';
import { MOCK_TEACHERS } from '../constants';
import { MapPin, Star, CheckCircle, MessageCircle } from 'lucide-react';

export const TeacherMarketplace: React.FC = () => {
  return (
    <div className="p-4 max-w-4xl mx-auto pb-24">
      <header className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Find a Teacher</h1>
          <p className="text-gray-500">Expert tutors verified by Divine Tech.</p>
        </div>
        <BubbleButton variant="secondary" size="sm">Filter by Subject</BubbleButton>
      </header>

      <div className="space-y-4">
        {MOCK_TEACHERS.map(teacher => (
          <Card key={teacher.id} className="flex flex-col md:flex-row gap-6 hover:shadow-2xl transition-shadow">
            <div className="flex-shrink-0">
              <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto md:mx-0 overflow-hidden">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${teacher.id}`} alt="Avatar" className="w-full h-full" />
              </div>
            </div>
            
            <div className="flex-grow text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
                <h3 className="text-xl font-bold text-gray-800">{teacher.name}</h3>
                {teacher.isVerified && <CheckCircle size={18} className="text-blue-500" />}
              </div>
              
              <div className="flex items-center justify-center md:justify-start gap-4 text-sm text-gray-500 mb-3">
                <span className="flex items-center gap-1"><MapPin size={14} /> {teacher.location}</span>
                <span className="flex items-center gap-1 text-yellow-600 font-bold"><Star size={14} fill="#D97706" /> {teacher.rating} ({teacher.reviews})</span>
              </div>

              <p className="text-gray-600 mb-4 text-sm line-clamp-2">{teacher.bio}</p>

              <div className="flex flex-wrap gap-2 justify-center md:justify-start mb-4">
                {teacher.subjects.map(sub => (
                  <span key={sub} className="px-3 py-1 bg-purple-50 text-purple-700 rounded-full text-xs font-bold border border-purple-100">
                    {sub}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex flex-col justify-center gap-3 border-t md:border-t-0 md:border-l border-gray-100 pt-4 md:pt-0 md:pl-6 min-w-[140px]">
              <div className="text-center">
                <span className="text-2xl font-bold text-gray-800">${teacher.hourlyRate}</span>
                <span className="text-xs text-gray-500">/hour</span>
              </div>
              <BubbleButton variant="primary" size="sm" fullWidth>Book Now</BubbleButton>
              <BubbleButton variant="success" size="sm" fullWidth icon={MessageCircle}>Chat</BubbleButton>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
