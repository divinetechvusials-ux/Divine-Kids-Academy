
import React, { useState, useEffect } from 'react';
import { Card, BubbleButton, Mascot } from '../components/UIComponents';
import { ArrowLeft, Volume2, Image as ImageIcon } from 'lucide-react';
import { SPELLING_WORDS } from '../constants';
import { speak, playSoundEffect } from '../utils/soundUtils';

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('');

export const AlphabetView: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);

  const handleLetterClick = (char: string) => {
    setSelectedLetter(char);
    
    // Play a gentle chime sound for engagement
    playSoundEffect('click'); 
    
    const wordData = SPELLING_WORDS.find(w => w.word.startsWith(char));
    
    if (wordData) {
      // Pronounce Letter -> Word -> Sentence
      // Example: "A. Apple. The red apple is crunchy and sweet."
      const sentence = wordData.sentence || "";
      speak(`${char}. ${wordData.word}. ${sentence}`);
    } else {
      // Pronounce Letter -> Lowercase representation
      // Example: "X. Small x."
      speak(`${char}. Small ${char.toLowerCase()}.`);
    }
  };

  const currentWordData = selectedLetter 
    ? SPELLING_WORDS.find(w => w.word.startsWith(selectedLetter)) 
    : null;

  return (
    <div className="p-4 max-w-4xl mx-auto pb-24 min-h-screen flex flex-col">
      <div className="flex items-center mb-6">
        <BubbleButton variant="secondary" size="sm" onClick={onExit} icon={ArrowLeft}>Back</BubbleButton>
        <h1 className="text-2xl font-bold text-gray-800 ml-4">Alphabet Adventure</h1>
      </div>

      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left: Letter Grid */}
        <Card className="order-2 md:order-1 h-full">
          <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
            {ALPHABET.map(char => (
              <button 
                key={char}
                onClick={() => handleLetterClick(char)}
                className={`aspect-square rounded-2xl flex items-center justify-center text-3xl font-black shadow-sm transition-all duration-200 border-b-4 ${
                  selectedLetter === char 
                    ? 'bg-[#6EC6FF] text-white border-blue-400 scale-105 shadow-blue-200 ring-2 ring-blue-100' 
                    : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50 hover:scale-105'
                }`}
              >
                {char}
              </button>
            ))}
          </div>
        </Card>

        {/* Right: Preview & Interaction */}
        <div className="order-1 md:order-2">
           <Card className="sticky top-4 bg-gradient-to-br from-yellow-50 to-white border-yellow-200 h-full flex flex-col items-center justify-center min-h-[300px] text-center p-8">
              {selectedLetter ? (
                <div className="animate-bounce-in w-full">
                  <div className="flex items-baseline justify-center gap-4 mb-6">
                    <span className="text-8xl font-black text-[#6EC6FF] drop-shadow-sm">{selectedLetter}</span>
                    <span className="text-6xl font-black text-blue-300">{selectedLetter.toLowerCase()}</span>
                  </div>
                  
                  {currentWordData ? (
                    <div className="bg-white p-6 rounded-3xl shadow-lg border-2 border-gray-50 max-w-sm mx-auto transform transition-all hover:scale-105">
                      <div className="text-8xl mb-4">{currentWordData.image}</div>
                      <h3 className="text-3xl font-bold text-gray-800 tracking-wider mb-2">{currentWordData.word}</h3>
                      {currentWordData.sentence && (
                        <p className="text-lg text-blue-600 font-medium italic bg-blue-50 p-2 rounded-xl">
                          "{currentWordData.sentence}"
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="text-gray-400 py-8">
                      <ImageIcon size={64} className="mx-auto mb-2 opacity-20" />
                      <p>Tap a letter to learn!</p>
                    </div>
                  )}

                  <div className="mt-8">
                    <BubbleButton 
                      onClick={() => handleLetterClick(selectedLetter)} 
                      variant="primary" 
                      icon={Volume2}
                      className="animate-pulse"
                    >
                      Hear it again
                    </BubbleButton>
                  </div>
                </div>
              ) : (
                <div className="text-center opacity-60">
                   <Mascot type="elephant" className="mx-auto mb-6 w-32 h-32" />
                   <h3 className="text-2xl font-bold text-gray-500">Pick a letter to start!</h3>
                </div>
              )}
           </Card>
        </div>
      </div>
    </div>
  );
};
