import React from 'react';
import { Card, BubbleButton } from '../components/UIComponents';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { Download, Award } from 'lucide-react';
import { COLORS } from '../constants';

const MASTERY_DATA = [
  { name: 'Spelling', value: 75, color: COLORS.skyBlue },
  { name: 'Math', value: 45, color: COLORS.gardenGreen },
  { name: 'Animals', value: 90, color: COLORS.sunYellow },
  { name: 'Logic', value: 30, color: COLORS.friendlyPurple },
];

const ACTIVITY_DATA = [
  { day: 'Mon', minutes: 20 },
  { day: 'Tue', minutes: 45 },
  { day: 'Wed', minutes: 30 },
  { day: 'Thu', minutes: 60 },
  { day: 'Fri', minutes: 15 },
  { day: 'Sat', minutes: 90 },
  { day: 'Sun', minutes: 40 },
];

interface Certificate {
  id: string;
  title: string;
  date: string;
  theme: 'orange' | 'green' | 'blue';
}

const CERTIFICATES: Certificate[] = [
  {
    id: 'c1',
    title: 'Spelling Bee Champ',
    date: 'Oct 24, 2025',
    theme: 'orange'
  },
  {
    id: 'c2',
    title: 'Math Master',
    date: 'Nov 02, 2025',
    theme: 'green'
  }
];

export const ParentDashboard: React.FC = () => {
  const handleDownload = (cert: Certificate) => {
    // In a real app, this would trigger a PDF generation or download URL
    const message = `Downloading certificate: ${cert.title}`;
    alert(message);
    console.log(message);
  };

  const getThemeStyles = (theme: string) => {
    switch (theme) {
      case 'green':
        return {
          bg: 'bg-gradient-to-br from-green-50 to-emerald-100',
          border: 'border-green-200',
          text: 'text-green-800',
          icon: 'text-green-600'
        };
      case 'blue':
        return {
          bg: 'bg-gradient-to-br from-blue-50 to-cyan-100',
          border: 'border-blue-200',
          text: 'text-blue-800',
          icon: 'text-blue-600'
        };
      case 'orange':
      default:
        return {
          bg: 'bg-gradient-to-br from-yellow-50 to-orange-100',
          border: 'border-orange-200',
          text: 'text-orange-800',
          icon: 'text-orange-500'
        };
    }
  };

  return (
    <div className="p-4 max-w-6xl mx-auto pb-24">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Parent Dashboard</h1>
        <p className="text-gray-500">Overview of Alex's progress</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Mastery Chart */}
        <Card className="col-span-1 lg:col-span-1">
          <h3 className="font-bold text-lg mb-4 text-gray-700">Subject Mastery</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={MASTERY_DATA}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {MASTERY_DATA.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-2 justify-center mt-2">
            {MASTERY_DATA.map(d => (
              <div key={d.name} className="flex items-center gap-1 text-xs">
                <div className="w-3 h-3 rounded-full" style={{ background: d.color }} />
                <span>{d.name}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Weekly Activity */}
        <Card className="col-span-1 lg:col-span-2">
          <h3 className="font-bold text-lg mb-4 text-gray-700">Weekly Activity (Minutes)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ACTIVITY_DATA}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                <Bar dataKey="minutes" fill={COLORS.skyBlue} radius={[10, 10, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Achievements / Stickers */}
        <Card className="col-span-1 md:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg text-gray-700">Sticker Book</h3>
            <span className="text-sm text-green-600 font-bold bg-green-100 px-3 py-1 rounded-full">12 Collected</span>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {[1,2,3,4,5].map(i => (
              <div key={i} className="flex-shrink-0 w-24 h-24 bg-yellow-50 rounded-full border-4 border-dashed border-yellow-200 flex items-center justify-center text-4xl grayscale opacity-50">
                ?
              </div>
            ))}
            <div className="flex-shrink-0 w-24 h-24 bg-white rounded-full border-4 border-yellow-400 flex items-center justify-center text-4xl shadow-lg transform rotate-6">
              🐢
            </div>
            <div className="flex-shrink-0 w-24 h-24 bg-white rounded-full border-4 border-purple-400 flex items-center justify-center text-4xl shadow-lg transform -rotate-3">
              🚀
            </div>
          </div>
        </Card>

        {/* Certificates */}
        <Card className="col-span-1">
          <h3 className="font-bold text-lg mb-4 text-gray-700">Certificates</h3>
          <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
            {CERTIFICATES.map(cert => {
              const styles = getThemeStyles(cert.theme);
              return (
                <div key={cert.id} className={`${styles.bg} p-4 rounded-xl border-2 ${styles.border} text-center transition-transform hover:scale-[1.02]`}>
                  <Award className={`mx-auto ${styles.icon} mb-2`} size={32} />
                  <h4 className={`font-bold ${styles.text}`}>{cert.title}</h4>
                  <p className={`text-xs ${styles.text} opacity-80 mb-3`}>Awarded {cert.date}</p>
                  <BubbleButton 
                    fullWidth 
                    variant="primary" 
                    size="sm" 
                    icon={Download}
                    onClick={() => handleDownload(cert)}
                  >
                    Download PDF
                  </BubbleButton>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
};
