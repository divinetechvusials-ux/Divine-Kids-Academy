import React, { useState, useEffect } from 'react';
import { Card, BubbleButton, Mascot } from '../components/UIComponents';
import { ArrowLeft, Star, Shuffle, CheckCircle, XCircle, Calculator, Grid3X3, Shapes, PlayCircle, ArrowRight, Video } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { VIDEOS } from '../constants';
import { speak } from '../utils/soundUtils';

type MathMode = 'menu' | 'add' | 'sub' | 'mult' | 'counting' | 'shapes';
type Difficulty = 'easy' | 'medium';

export const MathGame: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const navigate = useNavigate();
  const [mode, setMode] = useState<MathMode>('menu');
  const [difficulty, setDifficulty] = useState<Difficulty>('easy');
  const [score, setScore] = useState(0);
  const [problem, setProblem] = useState({ q: '', a: 0 });
  const [options, setOptions] = useState<number[]>([]);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  // Counting 1-100 State
  const [countHighlight, setCountHighlight] = useState<number | null>(null);

  useEffect(() => {
    if (['add', 'sub', 'mult'].includes(mode)) {
      generateProblem();
    }
  }, [mode, difficulty]);

  const generateProblem = () => {
    let a = 0, b = 0, ans = 0, symbol = '';
    
    if (mode === 'add') {
      const max = difficulty === 'easy' ? 10 : 20;
      a = Math.floor(Math.random() * (max + 1)); 
      b = Math.floor(Math.random() * (max + 1 - a)); // Ensures sum <= max
      ans = a + b;
      symbol = '+';
    } else if (mode === 'sub') {
      const max = difficulty === 'easy' ? 10 : 20;
      a = Math.floor(Math.random() * (max + 1));
      b = Math.floor(Math.random() * (a + 1)); // Ensures result >= 0
      ans = a - b;
      symbol = '-';
    } else if (mode === 'mult') {
      const max = difficulty === 'easy' ? 6 : 11; // Easy: 0-5, Med: 0-10
      a = Math.floor(Math.random() * max); 
      b = Math.floor(Math.random() * max);
      ans = a * b;
      symbol = '×';
    }

    setProblem({ q: `${a} ${symbol} ${b}`, a: ans });
    setFeedback(null);

    // Generate options
    const opts = new Set<number>();
    opts.add(ans);
    while (opts.size < 3) {
      // Generate distractors close to the answer
      const offset = Math.floor(Math.random() * 10) - 5;
      const val = Math.max(0, ans + offset);
      if (val !== ans) opts.add(val);
    }
    setOptions(Array.from(opts).sort(() => Math.random() - 0.5));
  };

  const handleAnswer = (val: number) => {
    if (val === problem.a) {
      setFeedback('correct');
      setScore(s => s + 10);
      const audio = new Audio('https://codeskulptor-demos.commondatastorage.googleapis.com/pang/arrow.mp3');
      audio.play().catch(() => {});
      setTimeout(generateProblem, 1000);
    } else {
      setFeedback('wrong');
      if ('vibrate' in navigator) navigator.vibrate(200);
      speak("Try again");
    }
  };

  const playNumber = (num: number) => {
    setCountHighlight(num);
    speak(num.toString());
  };

  const navigateToVideo = (category: string) => {
    // Find a relevant video to highlight, or just go to the category
    // We pass state to the VideoView
    navigate('/videos', { state: { categoryFilter: category } });
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto p-4 relative">
      <div className="flex justify-between items-center mb-6">
        <BubbleButton variant="secondary" size="sm" onClick={mode === 'menu' ? onExit : () => setMode('menu')} icon={ArrowLeft}>
            {mode === 'menu' ? 'Back' : 'Menu'}
        </BubbleButton>
        <div className="flex items-center gap-2 bg-green-100 px-4 py-2 rounded-full">
          <Star className="text-yellow-500 fill-yellow-500" />
          <span className="font-bold text-green-800">{score} Stars</span>
        </div>
      </div>

      {mode === 'menu' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in">
          <div className="col-span-1 md:col-span-2 bg-white p-6 rounded-3xl border-b-4 border-green-200 text-center mb-4">
             <Mascot type="elephant" className="mx-auto mb-4" />
             <h2 className="text-3xl font-bold text-green-700">Math & Shapes</h2>
             <p className="text-gray-500">Choose a game to play!</p>
          </div>

          <MenuCard title="Addition (+)" color="bg-blue-100 text-blue-700" onClick={() => setMode('add')} icon={<span className="text-4xl font-bold">+</span>} />
          <MenuCard title="Subtraction (-)" color="bg-red-100 text-red-700" onClick={() => setMode('sub')} icon={<span className="text-4xl font-bold">-</span>} />
          <MenuCard title="Multiplication (×)" color="bg-purple-100 text-purple-700" onClick={() => setMode('mult')} icon={<span className="text-4xl font-bold">×</span>} />
          <MenuCard title="Counting 1-100" color="bg-yellow-100 text-yellow-700" onClick={() => setMode('counting')} icon={<Grid3X3 size={32} />} />
          <MenuCard title="Shapes" color="bg-orange-100 text-orange-700" onClick={() => setMode('shapes')} icon={<Shapes size={32} />} />
        </div>
      )}

      {['add', 'sub', 'mult'].includes(mode) && (
        <Card className="flex-1 flex flex-col items-center justify-center relative animate-fade-in border-green-200 bg-gradient-to-br from-green-50 to-white">
          <div className="flex flex-col items-center mb-6 w-full">
            <div className="text-2xl text-gray-400 font-bold mb-4 uppercase tracking-widest">{mode === 'mult' ? 'Multiplication' : mode === 'add' ? 'Addition' : 'Subtraction'}</div>
            
            <div className="bg-white/50 p-1 rounded-full flex gap-1 border-2 border-gray-100">
              <button 
                onClick={() => setDifficulty('easy')} 
                className={`px-6 py-2 rounded-full font-bold transition-all ${difficulty === 'easy' ? 'bg-[#4CAF50] text-white shadow-md' : 'text-gray-500 hover:bg-gray-100'}`}
              >
                Easy {mode === 'mult' ? '(0-5)' : '(0-10)'}
              </button>
              <button 
                onClick={() => setDifficulty('medium')} 
                className={`px-6 py-2 rounded-full font-bold transition-all ${difficulty === 'medium' ? 'bg-[#FF9800] text-white shadow-md' : 'text-gray-500 hover:bg-gray-100'}`}
              >
                Medium {mode === 'mult' ? '(0-10)' : '(0-20)'}
              </button>
            </div>
          </div>
          
          <div className="bg-white px-12 py-8 rounded-3xl shadow-lg border-2 border-gray-100 mb-12">
            <span className="text-6xl md:text-8xl font-black text-gray-800">{problem.q} = ?</span>
          </div>

          <div className="grid grid-cols-3 gap-4 w-full max-w-lg">
            {options.map((opt) => (
               <BubbleButton 
                 key={opt} 
                 onClick={() => handleAnswer(opt)}
                 variant="primary"
                 className="text-4xl font-bold py-6"
                 fullWidth
               >
                 {opt}
               </BubbleButton>
            ))}
          </div>

          {feedback && (
             <div className={`mt-8 text-2xl font-bold ${feedback === 'correct' ? 'text-green-500 animate-bounce' : 'text-red-500 animate-shake'}`}>
               {feedback === 'correct' ? 'Correct! 🎉' : 'Try Again!'}
             </div>
          )}
        </Card>
      )}

      {mode === 'counting' && (
          <div className="animate-fade-in flex flex-col h-full">
             <div className="flex justify-between items-center mb-4 px-2">
                <h3 className="text-xl font-bold text-gray-700">Tap numbers to hear them!</h3>
                <BubbleButton size="sm" variant="danger" icon={PlayCircle} onClick={() => navigateToVideo('Math')}>Watch Video</BubbleButton>
             </div>
             <Card className="flex-1 bg-white border-yellow-200 overflow-y-auto">
                 <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
                     {Array.from({length: 100}, (_, i) => i + 1).map(num => (
                         <button
                           key={num}
                           onClick={() => playNumber(num)}
                           className={`aspect-square rounded-lg flex items-center justify-center font-bold text-lg sm:text-xl transition-all ${
                               countHighlight === num 
                               ? 'bg-[#FFD54F] text-yellow-900 scale-110 shadow-lg z-10' 
                               : 'bg-yellow-50 text-yellow-700 hover:bg-yellow-100'
                           }`}
                         >
                             {num}
                         </button>
                     ))}
                 </div>
             </Card>
          </div>
      )}

      {mode === 'shapes' && (
          <div className="animate-fade-in h-full">
             <div className="flex justify-between items-center mb-4 px-2">
                <h3 className="text-xl font-bold text-gray-700">Learn Shapes</h3>
                <BubbleButton size="sm" variant="danger" icon={PlayCircle} onClick={() => navigateToVideo('Colors')}>Watch Video</BubbleButton>
             </div>
             
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pb-20">
                 <ShapeCard name="Circle" color="bg-red-500" shapeClass="rounded-full" onClick={() => speak("Circle")} />
                 <ShapeCard name="Square" color="bg-blue-500" shapeClass="rounded-none" onClick={() => speak("Square")} />
                 <ShapeCard name="Triangle" color="bg-green-500" shapeClass="w-0 h-0 border-l-[60px] border-r-[60px] border-b-[100px] border-l-transparent border-r-transparent border-b-green-500 !bg-transparent !w-auto !h-auto" onClick={() => speak("Triangle")} />
                 <ShapeCard name="Rectangle" color="bg-purple-500" shapeClass="w-32 h-20 rounded-none" onClick={() => speak("Rectangle")} />
                 <ShapeCard name="Oval" color="bg-orange-500" shapeClass="rounded-[50%]" onClick={() => speak("Oval")} />
             </div>
          </div>
      )}
    </div>
  );
};

const MenuCard: React.FC<{ title: string, color: string, onClick: () => void, icon: React.ReactNode }> = ({ title, color, onClick, icon }) => (
    <button onClick={onClick} className={`p-6 rounded-3xl ${color} shadow-sm border-b-4 border-black/10 active:border-b-0 active:translate-y-1 transition-all flex flex-col items-center justify-center gap-2 hover:brightness-95`}>
        {icon}
        <span className="font-bold text-lg">{title}</span>
    </button>
);

const ShapeCard: React.FC<{ name: string, color: string, shapeClass: string, onClick?: () => void }> = ({ name, color, shapeClass, onClick }) => {
    return (
        <Card className="flex flex-col items-center justify-center p-8 cursor-pointer hover:shadow-xl transition-transform hover:scale-105" onClick={onClick}>
            <div className={`w-32 h-32 ${color} ${shapeClass} mb-4 shadow-inner flex items-center justify-center`}>
                {/* Visual only */}
            </div>
            <h3 className="text-2xl font-bold text-gray-700">{name}</h3>
            <span className="text-sm text-gray-400 mt-1">Tap to hear</span>
        </Card>
    );
}