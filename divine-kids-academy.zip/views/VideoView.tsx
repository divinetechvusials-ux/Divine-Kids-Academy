
import React, { useState, useEffect, useRef } from 'react';
import { BubbleButton, Card } from '../components/UIComponents';
import { ArrowLeft, PlayCircle, Lock, Layers, Sparkles, Globe, BookOpen, Crown, SkipForward, List, Loader2, RotateCw, Play, Settings, Download, CheckCircle, WifiOff, AlertTriangle } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { VIDEOS } from '../constants';
import { duckBackgroundMusic } from '../utils/soundUtils';

interface VideoProps {
  onExit: () => void;
}

const CATEGORIES = [
  { id: 'All', label: 'All', icon: null },
  { id: 'Alphabet', label: 'ABC', icon: null },
  { id: 'Math', label: '123', icon: null },
  { id: 'Colors', label: 'Colors', icon: null },
  { id: 'Science', label: 'Science', icon: Sparkles, premium: true },
  { id: 'Social Studies', label: 'World', icon: Globe, premium: true },
  { id: 'Reading', label: 'Read', icon: BookOpen, premium: true },
];

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

const styles = (
  <style>{`
    @keyframes shimmer {
      0% { transform: translateX(-100%); }
      100% { transform: translateX(100%); }
    }
    .animate-shimmer {
      animation: shimmer 2s infinite cubic-bezier(0.4, 0, 0.2, 1);
    }
  `}</style>
);

export const VideoView: React.FC<VideoProps> = ({ onExit }) => {
  const location = useLocation();
  const [activeVideo, setActiveVideo] = useState<typeof VIDEOS[0] | null>(null);
  const [currentPlaylistIndex, setCurrentPlaylistIndex] = useState(0);
  const [filter, setFilter] = useState<string>('All');
  const [isPremiumUnlocked, setIsPremiumUnlocked] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [playerError, setPlayerError] = useState<string | null>(null);
  
  // Player State
  const playerRef = useRef<any>(null);
  const [playerReady, setPlayerReady] = useState(false);
  const [watchNextSuggestion, setWatchNextSuggestion] = useState<typeof VIDEOS[0] | null>(null);
  
  // UX Features
  const [qualityLevels, setQualityLevels] = useState<string[]>([]);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [downloadedVideos, setDownloadedVideos] = useState<string[]>([]);
  const [isDownloading, setIsDownloading] = useState(false);

  // Check for incoming state from other views
  useEffect(() => {
    if (location.state && (location.state as any).categoryFilter) {
      setFilter((location.state as any).categoryFilter);
    }
  }, [location]);

  // Load YouTube API
  useEffect(() => {
    if (!window.YT) {
      // Check if script is already in the DOM to prevent duplicates
      const existingScript = document.querySelector('script[src="https://www.youtube.com/iframe_api"]');
      
      if (!existingScript) {
        const tag = document.createElement('script');
        tag.src = "https://www.youtube.com/iframe_api";
        // Safe injection: append to body instead of trying to insertBefore unstable nodes
        document.body.appendChild(tag);
        
        tag.onerror = () => {
           console.error("Failed to load YouTube Iframe API");
           setPlayerError("Unable to load video player. Please check your internet connection.");
        };
      }

      // Assign callback (will be called by the API once loaded)
      window.onYouTubeIframeAPIReady = () => {
        setPlayerReady(true);
      };
    } else {
      setPlayerReady(true);
    }
  }, []);

  // Initialize/Update Player when activeVideo changes
  useEffect(() => {
    if (!activeVideo) return;
    
    // If player script failed to load, don't try to init
    if (playerError && !window.YT) return;
    
    if (!playerReady) {
        // If we are waiting for player ready, show loading
        if (!playerError) setIsLoading(true);
        return;
    }

    // Reset error state
    setPlayerError(null);

    const videoId = activeVideo.type === 'playlist' && activeVideo.playlistItems
      ? activeVideo.playlistItems[currentPlaylistIndex].youtubeId
      : activeVideo.youtubeId;

    if (playerRef.current) {
      // Player exists, load new video
      playerRef.current.loadVideoById(videoId);
      setIsLoading(true); // Will be cleared by onStateChange
    } else {
      // Create new player
      try {
        playerRef.current = new window.YT.Player('youtube-player', {
          height: '100%',
          width: '100%',
          videoId: videoId,
          playerVars: {
            autoplay: 1,
            rel: 0,
            modestbranding: 1,
            controls: 1, // Keep native controls for scrubbing
            origin: window.location.origin,
          },
          events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange,
            'onPlaybackQualityChange': () => setShowQualityMenu(false),
            'onError': onPlayerError
          }
        });
      } catch (e) {
          console.error("Failed to initialize player:", e);
          setPlayerError("Could not start video player.");
      }
    }

    // Cleanup suggestion state
    setWatchNextSuggestion(null);

    return () => {
       // Optional cleanup if needed, but we usually want to keep the instance for speed
    };
  }, [activeVideo, currentPlaylistIndex, playerReady, playerError]);

  // Destroy player on unmount or when closing video
  useEffect(() => {
      if (!activeVideo && playerRef.current) {
          playerRef.current.destroy();
          playerRef.current = null;
          setPlayerError(null);
          // Ensure music comes back if video is closed
          duckBackgroundMusic(false);
      }
  }, [activeVideo]);

  const onPlayerReady = (event: any) => {
    setIsLoading(false);
    event.target.playVideo();
    // Get quality levels
    if (event.target.getAvailableQualityLevels) {
        setQualityLevels(event.target.getAvailableQualityLevels());
    }
  };

  const onPlayerStateChange = (event: any) => {
    // YT.PlayerState.PLAYING = 1, ENDED = 0, BUFFERING = 3, PAUSED = 2
    if (event.data === 1) { // PLAYING
       setIsLoading(false);
       duckBackgroundMusic(true);
    } else if (event.data === 2 || event.data === 0) { // PAUSED or ENDED
       duckBackgroundMusic(false);
    }
    
    if (event.data === 0) { // ENDED
       handleVideoEnded();
    }
  };

  const onPlayerError = (event: any) => {
      setIsLoading(false);
      duckBackgroundMusic(false);
      let msg = "Video unavailable.";
      // YouTube Error Codes:
      // 2: Invalid parameter
      // 5: HTML5 error
      // 100: Video requested not found or removed
      // 101, 150: Owner does not allow embedded players
      const code = event.data;
      if (code === 100) msg = "This video has been removed or is unavailable.";
      if (code === 101 || code === 150) msg = "This video cannot be played here (Restricted).";
      if (code === 5) msg = "HTML5 Player Error. Try reloading.";
      
      setPlayerError(msg);
  };

  const setQuality = (q: string) => {
      if (playerRef.current && playerRef.current.setPlaybackQuality) {
          playerRef.current.setPlaybackQuality(q);
          setShowQualityMenu(false);
      }
  };

  const handleDownload = () => {
      if (!activeVideo) return;
      if (!isPremiumUnlocked) {
          setShowPremiumModal(true);
          return;
      }
      setIsDownloading(true);
      // Simulate download
      setTimeout(() => {
          setIsDownloading(false);
          setDownloadedVideos(prev => [...prev, activeVideo.id]);
          alert("Video saved to offline library! (Simulation)");
      }, 2000);
  };

  const handleVideoEnded = () => {
    if (activeVideo?.type === 'playlist' && activeVideo.playlistItems) {
       if (currentPlaylistIndex < activeVideo.playlistItems.length - 1) {
          // Auto-play next in playlist
          setCurrentPlaylistIndex(prev => prev + 1);
       } else {
          // End of playlist
          generateWatchNext();
       }
    } else {
       // Single video ended
       generateWatchNext();
    }
  };

  const generateWatchNext = () => {
     // Find a random video from the same category or random
     const candidates = filteredVideos.filter(v => v.id !== activeVideo?.id && (!v.isPremium || isPremiumUnlocked));
     if (candidates.length > 0) {
         const next = candidates[Math.floor(Math.random() * candidates.length)];
         setWatchNextSuggestion(next);
     } else {
         // Fallback if no other videos
         setActiveVideo(null); 
     }
  };

  const filteredVideos = filter === 'All' 
    ? VIDEOS 
    : VIDEOS.filter(v => v.category === filter);

  const handleVideoClick = (video: typeof VIDEOS[0]) => {
    if (video.isPremium && !isPremiumUnlocked) {
      setShowPremiumModal(true);
    } else {
      setIsLoading(true);
      setActiveVideo(video);
      setCurrentPlaylistIndex(0);
      setWatchNextSuggestion(null);
    }
  };

  const handleNextVideo = () => {
    if (activeVideo?.type === 'playlist' && activeVideo.playlistItems) {
        if (currentPlaylistIndex < activeVideo.playlistItems.length - 1) {
            setCurrentPlaylistIndex(prev => prev + 1);
        } else {
            setCurrentPlaylistIndex(0); // Loop
        }
    }
  };

  const handleWatchNextClick = () => {
      if (watchNextSuggestion) {
          handleVideoClick(watchNextSuggestion);
      }
  };

  const handleReplay = () => {
      if (activeVideo?.type === 'playlist') {
          setCurrentPlaylistIndex(0);
      }
      playerRef.current?.seekTo(0);
      playerRef.current?.playVideo();
      setWatchNextSuggestion(null);
  };

  const getCurrentVideoId = () => {
      if (!activeVideo) return null;
      if (activeVideo.type === 'playlist' && activeVideo.playlistItems) {
          const item = activeVideo.playlistItems[currentPlaylistIndex];
          return item ? item.youtubeId : activeVideo.playlistItems[0]?.youtubeId;
      }
      return activeVideo.youtubeId;
  };

  const currentVideoId = getCurrentVideoId();
  const thumbnailUrl = currentVideoId ? `https://img.youtube.com/vi/${currentVideoId}/hqdefault.jpg` : '';

  const currentTitle = activeVideo?.type === 'playlist' && activeVideo.playlistItems
      ? activeVideo.playlistItems[currentPlaylistIndex].title
      : activeVideo?.title;
      
  const currentDuration = activeVideo?.type === 'playlist' && activeVideo.playlistItems
      ? activeVideo.playlistItems[currentPlaylistIndex].duration
      : activeVideo?.duration;

  // Calculate progress for playlist
  const progressPercent = activeVideo?.type === 'playlist' && activeVideo.playlistItems
      ? ((currentPlaylistIndex + 1) / activeVideo.playlistItems.length) * 100
      : 0;
  
  const isDownloaded = activeVideo && downloadedVideos.includes(activeVideo.id);

  return (
    <div className="p-4 max-w-7xl mx-auto pb-24 h-full flex flex-col relative">
      {styles}
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div className="flex items-center w-full md:w-auto">
          <BubbleButton variant="secondary" size="sm" onClick={onExit} icon={ArrowLeft}>Back</BubbleButton>
          <h1 className="text-2xl font-bold text-gray-800 ml-4">Video Class</h1>
        </div>
        
        <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 hide-scrollbar px-1">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setFilter(cat.id);
                  setActiveVideo(null);
                }}
                className={`px-4 py-2 rounded-full font-bold text-sm whitespace-nowrap transition-all flex items-center gap-1 ${
                  filter === cat.id 
                    ? 'bg-[#FF5252] text-white shadow-md' 
                    : 'bg-white text-gray-500 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                {Icon && <Icon size={14} />}
                {cat.label}
                {cat.premium && !isPremiumUnlocked && <Lock size={12} className="opacity-50" />}
              </button>
            )
          })}
        </div>
      </div>

      {activeVideo ? (
        <div className="flex-1 flex flex-col lg:flex-row gap-6 animate-fade-in w-full">
             <div className="flex-1 flex flex-col">
                 <div className="aspect-video w-full bg-black rounded-3xl overflow-hidden shadow-2xl mb-4 ring-4 ring-[#FF5252]/20 relative z-10 group bg-gray-900">
                    
                    {/* Error Overlay */}
                    {playerError && (
                        <div className="absolute inset-0 z-40 bg-gray-900 flex flex-col items-center justify-center p-6 text-center">
                            <AlertTriangle size={48} className="text-yellow-500 mb-4" />
                            <h3 className="text-white text-xl font-bold mb-2">Oops! Video Error</h3>
                            <p className="text-gray-400 mb-6 max-w-sm">{playerError}</p>
                            <BubbleButton onClick={() => setActiveVideo(null)} variant="secondary" size="sm">
                                Go Back
                            </BubbleButton>
                        </div>
                    )}

                    {/* Loading State - REFINED */}
                    {isLoading && !playerError && (
                        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-gray-900 rounded-3xl overflow-hidden">
                             {/* Thumbnail Background - Dimmed */}
                             <div 
                                className="absolute inset-0 bg-cover bg-center opacity-40 transition-opacity duration-500"
                                style={{ backgroundImage: `url(${thumbnailUrl})` }}
                             />
                             
                             {/* Shimmer Overlay */}
                             <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer" style={{ backgroundSize: '200% 100%' }} />

                             {/* Central Loading Pill */}
                             <div className="relative z-30 bg-black/40 backdrop-blur-md px-6 py-3 rounded-full border border-white/10 flex items-center gap-3 shadow-2xl animate-pulse">
                                 <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                 <span className="text-white font-medium text-sm tracking-wide">
                                     {activeVideo.type === 'playlist' ? 'Loading Playlist...' : 'Loading Video...'}
                                 </span>
                             </div>
                        </div>
                    )}
                    
                    {/* Watch Next Overlay */}
                    {!isLoading && !playerError && watchNextSuggestion && (
                        <div className="absolute inset-0 z-30 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center text-white p-6 animate-fade-in">
                            <h3 className="text-xl font-bold mb-4 text-gray-300">Up Next</h3>
                            <div className="bg-gray-800 p-4 rounded-2xl flex flex-col items-center mb-6 border-2 border-gray-700 max-w-sm w-full">
                                <div className="aspect-video w-full bg-black rounded-lg mb-2 overflow-hidden relative">
                                     <img 
                                        src={`https://img.youtube.com/vi/${watchNextSuggestion.type === 'playlist' && watchNextSuggestion.playlistItems ? watchNextSuggestion.playlistItems[0].youtubeId : watchNextSuggestion.youtubeId}/mqdefault.jpg`}
                                        className="w-full h-full object-cover opacity-70"
                                     />
                                     <div className="absolute inset-0 flex items-center justify-center">
                                         <PlayCircle size={32} className="text-white" />
                                     </div>
                                </div>
                                <span className="font-bold text-center line-clamp-1">{watchNextSuggestion.title}</span>
                            </div>
                            <div className="flex gap-4">
                                <BubbleButton onClick={handleReplay} variant="secondary" icon={RotateCw}>
                                    Replay
                                </BubbleButton>
                                <BubbleButton onClick={handleWatchNextClick} variant="success" icon={Play}>
                                    Play Next
                                </BubbleButton>
                            </div>
                        </div>
                    )}

                    {/* YouTube Player Container */}
                    <div id="youtube-player" className="w-full h-full" />
                 </div>
                 
                 {/* Progress Bar for Playlist */}
                 {activeVideo.type === 'playlist' && (
                     <div className="w-full bg-gray-100 rounded-full h-4 mb-4 overflow-hidden border border-gray-200 relative">
                         <div 
                            className="bg-gradient-to-r from-orange-400 to-[#FF5252] h-full rounded-full transition-all duration-500 ease-out shadow-[0_0_10px_rgba(255,82,82,0.5)]"
                            style={{ width: `${progressPercent}%` }}
                         />
                         <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                            Playlist Progress
                         </div>
                     </div>
                 )}

                 <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                     <div>
                        <h2 className="text-xl md:text-2xl font-bold text-gray-800 line-clamp-1">{currentTitle}</h2>
                        <div className="flex items-center gap-2 mt-2">
                            <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-bold uppercase tracking-wide">
                                {activeVideo.category}
                            </span>
                            <span className="text-sm text-gray-500">{currentDuration}</span>
                            {activeVideo.type === 'playlist' && (
                                <span className="flex items-center gap-1 text-xs text-purple-600 font-bold bg-purple-100 px-2 py-1 rounded">
                                    <Layers size={12} /> Playlist {currentPlaylistIndex + 1}/{activeVideo.playlistItems?.length}
                                </span>
                            )}
                        </div>
                     </div>
                     
                     <div className="flex gap-2 shrink-0 relative">
                         {/* Offline / Download Button */}
                         <BubbleButton 
                            onClick={handleDownload} 
                            variant={isDownloaded ? "success" : "secondary"} 
                            icon={isDownloading ? Loader2 : (isDownloaded ? CheckCircle : Download)}
                            disabled={isDownloading || isDownloaded}
                            className={isDownloading ? 'animate-spin' : ''}
                         >
                            {isDownloading ? '' : (isDownloaded ? 'Saved' : 'Save')}
                         </BubbleButton>

                         {/* Quality Selector */}
                         {qualityLevels.length > 0 && (
                             <div className="relative">
                                 <BubbleButton onClick={() => setShowQualityMenu(!showQualityMenu)} variant="secondary" icon={Settings}>
                                     Quality
                                 </BubbleButton>
                                 {showQualityMenu && (
                                     <div className="absolute bottom-full right-0 mb-2 bg-white rounded-xl shadow-xl border border-gray-100 p-2 min-w-[120px] z-50 animate-fade-in flex flex-col gap-1">
                                         {qualityLevels.map(q => (
                                             <button 
                                                key={q}
                                                onClick={() => setQuality(q)}
                                                className="px-4 py-2 hover:bg-gray-100 rounded-lg text-sm text-left font-bold text-gray-700 capitalize"
                                             >
                                                {q}
                                             </button>
                                         ))}
                                     </div>
                                 )}
                             </div>
                         )}

                         {activeVideo.type === 'playlist' && (
                             <BubbleButton onClick={handleNextVideo} variant="success" icon={SkipForward} disabled={watchNextSuggestion !== null}>
                                 Next
                             </BubbleButton>
                         )}
                         <BubbleButton variant="secondary" onClick={() => setActiveVideo(null)}>
                             Close
                         </BubbleButton>
                     </div>
                 </div>
             </div>

             {/* Playlist Queue */}
             {activeVideo.type === 'playlist' && activeVideo.playlistItems && (
                 <div className="lg:w-80 shrink-0 flex flex-col bg-white rounded-3xl border-2 border-gray-100 shadow-lg overflow-hidden h-[400px] lg:h-auto">
                    <div className="p-4 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
                        <span className="font-bold text-gray-700 flex items-center gap-2">
                            <List size={18} /> Up Next
                        </span>
                        <span className="text-xs bg-gray-200 px-2 py-1 rounded-full text-gray-600">
                            {activeVideo.playlistItems.length} videos
                        </span>
                    </div>
                    <div className="overflow-y-auto p-2 space-y-2 flex-1 scrollbar-thin scrollbar-thumb-gray-300">
                        {activeVideo.playlistItems.map((item, idx) => {
                            const isActive = idx === currentPlaylistIndex;
                            const isWatched = idx < currentPlaylistIndex;
                            
                            return (
                                <div 
                                    key={idx}
                                    onClick={() => {
                                        setIsLoading(true);
                                        setCurrentPlaylistIndex(idx);
                                        setWatchNextSuggestion(null);
                                    }}
                                    className={`flex gap-3 p-2 rounded-xl cursor-pointer transition-all ${
                                        isActive 
                                            ? 'bg-blue-50 border-blue-200 shadow-sm' 
                                            : isWatched 
                                                ? 'opacity-60 bg-gray-50 border-transparent'
                                                : 'hover:bg-gray-50 border-transparent'
                                    } border-2`}
                                >
                                    <div className="relative w-24 h-16 bg-gray-200 rounded-lg overflow-hidden shrink-0 group">
                                        <img 
                                            src={`https://img.youtube.com/vi/${item.youtubeId}/default.jpg`}
                                            alt={item.title}
                                            className="w-full h-full object-cover"
                                        />
                                        {isActive && (
                                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                                <div className="w-2 h-2 bg-[#FF5252] rounded-full animate-pulse"></div>
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex flex-col justify-center min-w-0">
                                        <h4 className={`text-sm font-bold line-clamp-2 ${isActive ? 'text-blue-700' : 'text-gray-700'}`}>
                                            {item.title}
                                        </h4>
                                        <span className="text-xs text-gray-400 mt-1">{item.duration}</span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                 </div>
             )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {/* Offline Library Prompt */}
            {downloadedVideos.length > 0 && filter === 'All' && (
                <div 
                    onClick={() => alert("This opens the offline video library (Feature in progress)")}
                    className="bg-green-50 rounded-2xl p-6 flex flex-col items-center justify-center text-green-700 border-2 border-dashed border-green-300 min-h-[200px] hover:bg-green-100 transition-colors cursor-pointer"
                >
                    <WifiOff size={48} className="mb-2 text-green-500" />
                    <span className="font-bold text-center">Offline Library</span>
                    <span className="text-xs mt-1 text-green-600">{downloadedVideos.length} videos saved</span>
                </div>
            )}

            {filteredVideos.map(video => {
                const isLocked = video.isPremium && !isPremiumUnlocked;
                const isSaved = downloadedVideos.includes(video.id);
                
                return (
                <div 
                    key={video.id}
                    onClick={() => handleVideoClick(video)}
                    className="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer border-2 border-transparent hover:border-[#FF5252] transform hover:-translate-y-1 flex flex-col relative"
                >
                    <div className="relative aspect-video bg-gray-200">
                        <img 
                            src={`https://img.youtube.com/vi/${video.type === 'playlist' && video.playlistItems ? video.playlistItems[0].youtubeId : video.youtubeId}/mqdefault.jpg`} 
                            onError={(e) => {
                                (e.target as HTMLImageElement).src = 'https://img.youtube.com/vi/b051ktudQDQ/mqdefault.jpg'; 
                            }}
                            alt={video.title} 
                            className={`w-full h-full object-cover transition-all ${isLocked ? 'blur-[2px] grayscale' : ''}`}
                            loading="lazy"
                        />
                        <div className="absolute top-2 right-2 flex gap-1">
                             {video.type === 'playlist' && (
                                <div className="bg-purple-600 text-white text-xs px-2 py-1 rounded flex items-center gap-1 shadow-sm">
                                    <Layers size={12} /> Playlist
                                </div>
                            )}
                            {video.isPremium && (
                                <div className="bg-yellow-500 text-white text-xs px-2 py-1 rounded flex items-center gap-1 shadow-sm">
                                    <Crown size={12} />
                                </div>
                            )}
                            {isSaved && (
                                <div className="bg-green-500 text-white text-xs px-2 py-1 rounded flex items-center gap-1 shadow-sm">
                                    <CheckCircle size={12} />
                                </div>
                            )}
                        </div>
                        <div className="absolute inset-0 bg-black/10 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                            <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform ${isLocked ? 'bg-gray-800/80 text-white' : 'bg-white/90 text-[#FF5252]'}`}>
                                {isLocked ? <Lock size={24} /> : <PlayCircle size={32} fill="currentColor" />}
                            </div>
                        </div>
                    </div>
                    <div className="p-4 flex-1 flex flex-col">
                        <h3 className="font-bold text-gray-800 line-clamp-2 mb-1">{video.title}</h3>
                        <span className="text-xs text-gray-500 uppercase tracking-wide mt-auto">{video.category}</span>
                    </div>
                </div>
            )})}
            
            {!isPremiumUnlocked && (
                 <div 
                    onClick={() => setShowPremiumModal(true)}
                    className="bg-gradient-to-br from-yellow-50 to-orange-100 rounded-2xl p-6 flex flex-col items-center justify-center text-yellow-700 border-2 border-dashed border-yellow-300 min-h-[200px] hover:bg-yellow-100 transition-colors cursor-pointer"
                 >
                    <Crown size={48} className="mb-2 text-yellow-500 animate-pulse" />
                    <span className="font-bold text-center">Unlock Premium Library</span>
                    <span className="text-xs mt-1 text-yellow-600">Science, World & Reading</span>
                </div>
            )}
        </div>
      )}

      {showPremiumModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fade-in">
           <Card className="max-w-md w-full relative overflow-hidden">
               <button onClick={() => setShowPremiumModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                   <Lock size={24} />
               </button>
               <div className="text-center pt-4">
                   <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-yellow-200">
                       <Crown size={40} className="text-yellow-600" fill="#CA8A04" />
                   </div>
                   <h2 className="text-2xl font-bold text-gray-800 mb-2">Unlock Divine Kids Premium</h2>
                   <p className="text-gray-600 mb-6 px-4">
                       Get unlimited access to Science, Geography, Reading and 100+ exclusive videos!
                   </p>
                   <BubbleButton fullWidth onClick={() => { setIsPremiumUnlocked(true); setShowPremiumModal(false); }} variant="warning" size="lg">
                       Unlock Premium
                   </BubbleButton>
               </div>
           </Card>
        </div>
      )}
    </div>
  );
};
