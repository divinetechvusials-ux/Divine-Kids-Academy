
// Centralized sound utilities

// Background Music (General App Loop)
export const BG_MUSIC_URL = "https://ia800605.us.archive.org/32/items/Childrens_Music_Collection/Loop%20-%20Happy.mp3"; 

// Instrumental Backing Tracks for Songs
// ABC: Twinkle Twinkle Little Star (Music Box Version)
export const ABC_INSTRUMENTAL = "https://ia800201.us.archive.org/12/items/TwinkleTwinkleLittleStar_169/TwinkleTwinkleLittleStar.mp3"; 
// Counting: Simple Rhythmic Drum Beat
export const COUNT_INSTRUMENTAL = "https://ia803402.us.archive.org/14/items/drum-beat-95-bpm/Drum%20Beat%20-%2095%20bpm.mp3";

let backgroundAudio: HTMLAudioElement | null = null;
let currentInstrumental: HTMLAudioElement | null = null;
let isMusicPlaying = false;
const BASE_VOLUME = 0.05; // Very low volume for non-disruptive background
const DUCKED_VOLUME = 0.01; // Almost silent when other audio is playing

export const initBackgroundMusic = () => {
  if (!backgroundAudio) {
    backgroundAudio = new Audio(BG_MUSIC_URL);
    backgroundAudio.loop = true;
    backgroundAudio.volume = BASE_VOLUME;
    
    backgroundAudio.onerror = (e) => {
      console.warn("Background music failed to load.", e);
      backgroundAudio = null;
    };
  }
};

export const startBackgroundMusic = (): boolean => {
    if (!backgroundAudio) initBackgroundMusic();
    
    if (backgroundAudio && !isMusicPlaying) {
        const playPromise = backgroundAudio.play();
        if (playPromise !== undefined) {
            playPromise
            .then(() => {
                isMusicPlaying = true;
            })
            .catch(e => {
                console.warn("Auto-play prevented:", e.message);
                isMusicPlaying = false;
            });
        }
    }
    return isMusicPlaying;
};

export const toggleBackgroundMusic = (): boolean => {
  if (!backgroundAudio) initBackgroundMusic();
  
  if (backgroundAudio) {
    if (isMusicPlaying) {
      backgroundAudio.pause();
      isMusicPlaying = false;
    } else {
      startBackgroundMusic();
      isMusicPlaying = true; // Optimistic update, promise in start handles actual
    }
  }
  return isMusicPlaying;
};

export const getMusicState = () => isMusicPlaying;

export const duckBackgroundMusic = (shouldDuck: boolean) => {
  if (!backgroundAudio) return;
  // Smoothly transition volume if possible (simple assignment for now)
  backgroundAudio.volume = shouldDuck ? DUCKED_VOLUME : BASE_VOLUME;
};

// Play a specific instrumental track for a game/song
export const playInstrumental = (type: 'abc' | 'count', onError?: (error: string) => void) => {
  // Ensure we stop any currently playing track cleanly
  stopInstrumental(); 

  const url = type === 'abc' ? ABC_INSTRUMENTAL : COUNT_INSTRUMENTAL;
  const audio = new Audio(url);
  audio.volume = 0.4; // Louder than BG, softer than voice
  currentInstrumental = audio;
  
  // Handle Loading Errors
  audio.onerror = () => {
      const msg = `Instrumental track failed to load: ${url}`;
      console.warn(msg);
      duckBackgroundMusic(false);
      if (currentInstrumental === audio) currentInstrumental = null;
      if (onError) onError("Music unavailable. Singing without backing track.");
  };

  duckBackgroundMusic(true);
  
  const playPromise = audio.play();
  
  if (playPromise !== undefined) {
      playPromise.catch(e => {
          // 'AbortError' is expected if we call pause() while it's loading/starting.
          if (e.name === 'AbortError') return;
          
          console.warn("Instrumental play warning:", e.message);
          duckBackgroundMusic(false);
          if (onError) onError("Audio playback blocked. Check browser settings.");
      });
  }
  
  audio.onended = () => {
    duckBackgroundMusic(false);
    if (currentInstrumental === audio) currentInstrumental = null;
  };
};

export const stopInstrumental = () => {
  if (currentInstrumental) {
    try {
        currentInstrumental.pause();
        currentInstrumental.currentTime = 0;
    } catch (e) {
        // Ignore errors if audio wasn't playing or ready
    }
    currentInstrumental = null;
    duckBackgroundMusic(false);
  }
};

// Child Voice Synthesis
export const speak = (text: string, onEnd?: () => void, rate: number = 1.0, pitch: number = 1.4) => {
  if (!('speechSynthesis' in window)) return;

  // Cancel previous speech to prevent overlapping
  window.speechSynthesis.cancel();
  // Ensure we reset ducking if previous speech was canceled
  duckBackgroundMusic(false);
  
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = rate; 
  utterance.pitch = pitch; 
  utterance.volume = 1.0;
  
  const voices = window.speechSynthesis.getVoices();
  const preferredVoice = voices.find(v => 
    v.name.includes('Google US English') || 
    v.name.includes('Samantha') || 
    v.name.includes('Zira')
  );
  
  if (preferredVoice) {
    utterance.voice = preferredVoice;
  }

  // Duck music when speaking starts
  utterance.onstart = () => {
      duckBackgroundMusic(true);
  };

  utterance.onend = () => {
    duckBackgroundMusic(false);
    if (onEnd) onEnd();
  };

  utterance.onerror = (event) => {
      duckBackgroundMusic(false);
      // Ignore interruption/cancellation errors as they are part of normal flow
      if (event.error === 'interrupted' || event.error === 'canceled') {
          return;
      }
      console.warn("Speech synthesis warning:", event.error);
      if (onEnd) onEnd(); 
  };

  window.speechSynthesis.speak(utterance);
};

export const playSoundEffect = (type: 'correct' | 'wrong' | 'click') => {
  let url = '';
  // Stable sound effects
  if (type === 'correct') url = 'https://codeskulptor-demos.commondatastorage.googleapis.com/pang/arrow.mp3';
  if (type === 'wrong') url = 'https://codeskulptor-demos.commondatastorage.googleapis.com/assets/sound/bgsound.mp3'; 
  if (type === 'click') url = 'https://codeskulptor-demos.commondatastorage.googleapis.com/week7-brrring.m4a';
  
  if (url) {
    const audio = new Audio(url);
    audio.volume = 0.3; // Louder than BG
    audio.play().catch(() => {});
  }
};
