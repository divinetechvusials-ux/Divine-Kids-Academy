
import React, { useEffect, useState } from 'react';
import { Mascot } from './UIComponents';
import { MapPin } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    // Animation sequence timings
    const timers = [
      setTimeout(() => setStage(1), 500),   // Show Logo
      setTimeout(() => setStage(2), 1500),  // Show Company Info
      setTimeout(() => setStage(3), 2800),  // Show Mission
      setTimeout(() => onFinish(), 5000),   // Transition to App
    ];

    return () => timers.forEach(t => clearTimeout(t));
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-[100] bg-white flex flex-col items-center justify-center overflow-hidden font-[Fredoka]">
      <style>{`
        @keyframes logoEntry {
          0% { transform: scale(0.5) rotate(-10deg); opacity: 0; }
          70% { transform: scale(1.1) rotate(5deg); }
          100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }
        @keyframes gearRotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-logo-entry { animation: logoEntry 1s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; }
        .animate-gear { animation: gearRotate 10s linear infinite; }
      `}</style>

      {/* Background soft glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-50 rounded-full blur-[100px] opacity-50" />

      {/* Logo Container */}
      <div className={`transition-all duration-1000 ${stage >= 1 ? 'opacity-1 scale-100' : 'opacity-0 scale-50'}`}>
        <div className="relative w-48 h-48 mb-8 animate-logo-entry">
          {/* Logo Representation: Using a stylized gear-brain visual based on the provided image */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-32 h-32 bg-gradient-to-tr from-blue-500 via-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-xl">
               <span className="text-6xl">🧠</span>
            </div>
            {/* Satellite Gears */}
            <div className="absolute -top-2 -right-2 w-12 h-12 bg-orange-400 rounded-full flex items-center justify-center animate-gear shadow-lg border-2 border-white">
                <span className="text-xl">⚙️</span>
            </div>
            <div className="absolute -bottom-2 -left-2 w-10 h-10 bg-blue-400 rounded-full flex items-center justify-center animate-gear shadow-lg border-2 border-white" style={{ animationDirection: 'reverse' }}>
                <span className="text-lg">⚙️</span>
            </div>
          </div>
        </div>
      </div>

      {/* Company Branding */}
      <div className={`text-center px-6 transition-all duration-1000 transform ${stage >= 2 ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        <h1 className="text-4xl font-extrabold text-gray-800 mb-2 tracking-tight">
          DIVINE TECH
        </h1>
        <div className="flex items-center justify-center gap-2 text-blue-600 font-bold uppercase tracking-[0.2em] text-sm mb-6">
          <MapPin size={16} />
          <span>Jerusalem, Israel</span>
        </div>
      </div>

      {/* App Detail / Importance */}
      <div className={`max-w-md text-center px-10 transition-all duration-1000 ${stage >= 3 ? 'opacity-100' : 'opacity-0'}`}>
        <p className="text-gray-500 text-lg leading-relaxed">
          The future of learning starts with safety and expertise. 
          <br/>
          <span className="text-purple-600 font-bold">Divine Kids Academy</span> is designed to bridge the gap between digital play and essential classroom foundations.
        </p>
      </div>

      {/* Loading Indicator */}
      <div className="absolute bottom-12 flex flex-col items-center">
        <div className="w-48 h-1 bg-gray-100 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-blue-400 to-purple-500 transition-all duration-[5000ms] ease-linear" style={{ width: stage === 3 ? '100%' : '0%' }} />
        </div>
        <span className="text-[10px] text-gray-300 font-bold uppercase tracking-widest mt-3">Initialising Academy...</span>
      </div>
    </div>
  );
};
