import React, { ErrorInfo, ReactNode } from 'react';
import { Card, BubbleButton, Mascot } from './UIComponents';
import { RefreshCcw, Home } from 'lucide-react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * ErrorBoundary component to catch JavaScript errors anywhere in their child component tree,
 * log those errors, and display a fallback UI instead of the component tree that crashed.
 */
// Fixed Error: Use React.Component explicitly to ensure base members are inherited correctly
export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    // Initialize state in the constructor to avoid property shadowing and ensure setState works correctly
    this.state = {
      hasError: false,
      error: null
    };
  }

  // Update state when an error occurs in the child component tree
  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
      window.location.hash = '/';
      // Fixed Error line 42: setState is correctly inherited from React.Component
      this.setState({ hasError: false, error: null });
  };

  render() {
    // Check error state to determine whether to render children or fallback UI
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#F0F9FF] flex items-center justify-center p-4">
          <Card className="max-w-md w-full text-center border-red-200 bg-red-50">
            <Mascot type="sun" className="mx-auto mb-6 opacity-50 grayscale" />
            <h1 className="text-2xl font-bold text-red-600 mb-2">Oops! Something went wrong.</h1>
            <p className="text-gray-600 mb-6">
              We're sorry, but we ran into an unexpected issue.
            </p>
            <div className="flex gap-4 justify-center">
              <BubbleButton onClick={this.handleGoHome} variant="secondary" icon={Home}>
                Go Home
              </BubbleButton>
              <BubbleButton onClick={this.handleReload} variant="primary" icon={RefreshCcw}>
                Reload App
              </BubbleButton>
            </div>
          </Card>
        </div>
      );
    }

    // Fixed Error line 70: props.children is now accessible from the base class
    return this.props.children;
  }
}