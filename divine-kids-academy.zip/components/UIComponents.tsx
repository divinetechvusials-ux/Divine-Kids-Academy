import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  icon?: LucideIcon;
  fullWidth?: boolean;
}

export const BubbleButton: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  icon: Icon, 
  className = '', 
  fullWidth = false,
  ...props 
}) => {
  const baseStyle = "font-bold rounded-full shadow-[0_6px_0_rgb(0,0,0,0.15)] active:shadow-[0_2px_0_rgb(0,0,0,0.15)] active:translate-y-1 transition-all duration-150 flex items-center justify-center gap-2 border-2 border-white/20";
  
  const variants = {
    primary: "bg-[#6EC6FF] text-white hover:bg-[#5ac0ff]",
    secondary: "bg-[#9C27B0] text-white hover:bg-[#8e24aa]",
    success: "bg-[#4CAF50] text-white hover:bg-[#43a047]",
    warning: "bg-[#FFD54F] text-[#5D4037] hover:bg-[#ffcf40]",
    danger: "bg-[#FF5252] text-white hover:bg-[#ff1744]"
  };

  const sizes = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-xl",
    xl: "px-10 py-6 text-2xl"
  };

  return (
    <button 
      className={`${baseStyle} ${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {Icon && <Icon size={size === 'xl' ? 32 : 24} />}
      {children}
    </button>
  );
};

export const Card: React.FC<{ children: React.ReactNode; className?: string; color?: string }> = ({ 
  children, 
  className = '',
  color = 'white'
}) => (
  <div className={`bg-${color} rounded-3xl shadow-xl p-6 ${className} bg-white border-4 border-gray-100`}>
    {children}
  </div>
);

export const Mascot: React.FC<{ type: 'sun' | 'elephant'; className?: string }> = ({ type, className = '' }) => {
  if (type === 'sun') {
    return (
      <div className={`relative w-24 h-24 bg-[#FFD54F] rounded-full border-4 border-orange-300 animate-pulse flex items-center justify-center ${className}`}>
        <div className="text-4xl">☀️</div>
        <div className="absolute -top-2 -right-2 bg-white px-2 py-1 rounded-full text-xs font-bold shadow-md">Hi!</div>
      </div>
    );
  }
  return (
    <div className={`relative w-24 h-24 bg-[#6EC6FF] rounded-full border-4 border-blue-400 flex items-center justify-center ${className}`}>
      <div className="text-4xl">🐘</div>
    </div>
  );
};
