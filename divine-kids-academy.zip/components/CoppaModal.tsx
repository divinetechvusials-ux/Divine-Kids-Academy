import React, { useState } from 'react';
import { BubbleButton, Card } from './UIComponents';
import { Check, ShieldCheck } from 'lucide-react';

interface CoppaModalProps {
  onConsent: () => void;
}

export const CoppaModal: React.FC<CoppaModalProps> = ({ onConsent }) => {
  const [step, setStep] = useState(1);
  const [parentName, setParentName] = useState('');
  const [isChecked, setIsChecked] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <Card className="max-w-md w-full animate-bounce-in">
        <div className="text-center mb-6">
          <ShieldCheck className="mx-auto text-[#4CAF50] w-16 h-16 mb-4" />
          <h2 className="text-2xl font-bold text-gray-800">Parents, we need you!</h2>
          <p className="text-gray-500 text-sm mt-2">Divine Kids Academy is COPPA Compliant.</p>
        </div>

        {step === 1 && (
          <div className="space-y-4">
            <p className="text-gray-700 text-center">
              To keep this app safe for your child, we require a parent or guardian to set up the account. We collect minimal data and never share personal information with third parties without consent.
            </p>
            <BubbleButton fullWidth onClick={() => setStep(2)} variant="primary">
              I am a Parent/Guardian
            </BubbleButton>
            <p className="text-xs text-center text-gray-400 mt-4">
              By continuing, you agree to our Terms & Privacy Policy 2026.
            </p>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-xl text-sm text-blue-800 mb-4">
              <strong>Parental Consent:</strong> I authorize Divine Tech Company Limited to create an account for my child. I understand I can review or delete this information at any time.
            </div>
            
            <input 
              type="text" 
              placeholder="Enter Parent Full Name"
              className="w-full p-3 border-2 border-gray-200 rounded-xl focus:border-[#6EC6FF] outline-none"
              value={parentName}
              onChange={(e) => setParentName(e.target.value)}
            />

            <label className="flex items-center gap-3 p-2 cursor-pointer">
              <div 
                className={`w-6 h-6 rounded border-2 flex items-center justify-center ${isChecked ? 'bg-[#4CAF50] border-[#4CAF50]' : 'border-gray-300'}`}
                onClick={() => setIsChecked(!isChecked)}
              >
                {isChecked && <Check size={16} className="text-white" />}
              </div>
              <span className="text-sm text-gray-600">I agree to the Terms & Data Privacy Policy.</span>
            </label>

            <BubbleButton 
              fullWidth 
              onClick={onConsent} 
              variant="success" 
              disabled={!isChecked || parentName.length < 3}
              className={!isChecked || parentName.length < 3 ? 'opacity-50 cursor-not-allowed' : ''}
            >
              Grant Consent & Start
            </BubbleButton>
          </div>
        )}
      </Card>
    </div>
  );
};
