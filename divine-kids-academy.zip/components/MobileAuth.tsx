
import React, { useState, useEffect, useRef } from 'react';
import { Card, BubbleButton } from './UIComponents';
import { COUNTRY_DATA } from '../constants';
import { Phone, ChevronDown, Check, ArrowRight, ShieldCheck, Loader2, RefreshCw, Bell, Smartphone } from 'lucide-react';

interface MobileAuthProps {
  onAuthenticated: (phone: string) => void;
}

export const MobileAuth: React.FC<MobileAuthProps> = ({ onAuthenticated }) => {
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [selectedCountry, setSelectedCountry] = useState(COUNTRY_DATA.find(c => c.code === 'SL') || COUNTRY_DATA[0]);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [isSending, setIsSending] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [timer, setTimer] = useState(0);
  
  // Real-time OTP State
  const [currentSecretCode, setCurrentSecretCode] = useState<string | null>(null);
  const [incomingSms, setIncomingSms] = useState<{ visible: boolean; code: string }>({ visible: false, code: '' });

  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (timer > 0) {
      const interval = setInterval(() => setTimer(t => t - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [timer]);

  const generateOtp = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    return code;
  };

  const handleSendOtp = async () => {
    if (phoneNumber.length < 7) return;
    setIsSending(true);
    
    // Simulate API Latency & Backend Processing
    setTimeout(() => {
      const newCode = generateOtp();
      setCurrentSecretCode(newCode);
      setIsSending(false);
      setStep('otp');
      setTimer(60);
      
      // Simulate real-time delivery with a "Push Notification"
      setTimeout(() => {
        setIncomingSms({ visible: true, code: newCode });
        // Auto-hide notification after 8 seconds
        setTimeout(() => setIncomingSms(prev => ({ ...prev, visible: false })), 8000);
      }, 1000);
      
      console.log(`[DIVINE TECH AUTH] Sent unique OTP ${newCode} to ${selectedCountry.dial}${phoneNumber}`);
    }, 1500);
  };

  const handleVerifyOtp = async () => {
    const code = otp.join('');
    if (code.length < 6) return;
    
    setIsVerifying(true);
    
    // Validate against the dynamic code generated earlier
    setTimeout(() => {
      if (code === currentSecretCode) {
        onAuthenticated(selectedCountry.dial + phoneNumber);
      } else {
        alert("Invalid OTP! Please check the code sent to your device.");
        setIsVerifying(false);
        setOtp(['', '', '', '', '', '']);
        otpRefs.current[0]?.focus();
      }
    }, 1200);
  };

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);

    // Auto-focus next
    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const filteredCountries = COUNTRY_DATA.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.dial.includes(searchQuery)
  );

  return (
    <div className="fixed inset-0 z-[110] bg-[#6EC6FF] flex flex-col items-center justify-center p-4 font-[Fredoka] overflow-hidden">
      
      {/* SIMULATED PUSH NOTIFICATION (Receiving the SMS) */}
      <div className={`fixed top-4 left-4 right-4 max-w-md mx-auto z-[200] transition-all duration-700 transform ${incomingSms.visible ? 'translate-y-0 opacity-100' : '-translate-y-32 opacity-0 pointer-events-none'}`}>
        <div className="bg-white/90 backdrop-blur-md rounded-2xl p-4 shadow-2xl border-l-4 border-blue-500 flex items-start gap-3">
          <div className="bg-blue-500 p-2 rounded-xl text-white">
            <Bell size={20} className="animate-ring" />
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-center mb-1">
               <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Messages</span>
               <span className="text-[10px] text-gray-400">now</span>
            </div>
            <p className="text-sm font-bold text-gray-800">Divine Tech Gateway</p>
            <p className="text-xs text-gray-600 mt-1">
                Your Academy verification code is: <span className="font-black text-blue-600 tracking-wider text-sm">{incomingSms.code}</span>. Do not share this code.
            </p>
          </div>
        </div>
      </div>

      <Card className="max-w-md w-full animate-bounce-in shadow-2xl overflow-hidden relative border-t-8 border-[#9C27B0]">
        {step === 'phone' ? (
          <div className="p-6">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-inner relative">
                <Smartphone className="text-[#6EC6FF] w-10 h-10" />
                <div className="absolute -top-1 -right-1 bg-green-500 w-5 h-5 rounded-full border-2 border-white animate-pulse" />
              </div>
              <h2 className="text-2xl font-bold text-gray-800">Secure Parent Login</h2>
              <p className="text-gray-500 text-sm mt-2">Enter your mobile number to receive a unique verification code.</p>
            </div>

            <div className="space-y-4">
              {/* Country Selection */}
              <div className="relative">
                <button 
                  onClick={() => setShowCountryPicker(true)}
                  className="w-full flex items-center justify-between p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl hover:border-blue-200 transition-all text-left"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{selectedCountry.flag}</span>
                    <span className="font-bold text-gray-700">{selectedCountry.name}</span>
                  </div>
                  <ChevronDown className="text-gray-400" />
                </button>

                {showCountryPicker && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-100 rounded-2xl shadow-xl z-50 max-h-64 overflow-hidden flex flex-col animate-fade-in">
                    <div className="p-3 border-b border-gray-100">
                      <input 
                        type="text" 
                        placeholder="Search country..."
                        className="w-full p-2 bg-gray-50 rounded-lg outline-none text-sm"
                        autoFocus
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <div className="overflow-y-auto flex-1 scrollbar-thin scrollbar-thumb-gray-200">
                      {filteredCountries.map(country => (
                        <button
                          key={country.code}
                          onClick={() => {
                            setSelectedCountry(country);
                            setShowCountryPicker(false);
                            setSearchQuery('');
                          }}
                          className="w-full flex items-center gap-3 p-4 hover:bg-blue-50 transition-colors text-left"
                        >
                          <span className="text-2xl">{country.flag}</span>
                          <span className="flex-1 font-medium text-gray-700">{country.name}</span>
                          <span className="text-gray-400 font-bold">{country.dial}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Number Input */}
              <div className="flex gap-2">
                <div className="p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl text-gray-500 font-bold min-w-[70px] text-center">
                  {selectedCountry.dial}
                </div>
                <input 
                  type="tel" 
                  placeholder="Mobile number"
                  className="flex-1 p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-[#6EC6FF] outline-none font-bold text-gray-700 tracking-wider"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                />
              </div>

              <div className="pt-4">
                <BubbleButton 
                  fullWidth 
                  onClick={handleSendOtp} 
                  variant="primary" 
                  size="lg"
                  disabled={isSending || phoneNumber.length < 7}
                  className={phoneNumber.length < 7 ? 'opacity-50' : ''}
                >
                  {isSending ? (
                    <div className="flex items-center gap-2">
                      <Loader2 className="animate-spin" />
                      <span>Contacting Gateway...</span>
                    </div>
                  ) : (
                    <>
                      <span>Generate Security Code</span>
                      <ArrowRight size={20} className="ml-2" />
                    </>
                  )}
                </BubbleButton>
              </div>

              <div className="flex items-center justify-center gap-2 text-[10px] text-gray-400 mt-6 font-bold uppercase tracking-widest">
                  <ShieldCheck size={12} className="text-green-500" />
                  <span>Encrypted by Divine Tech Gateway</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-6">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-inner">
                <ShieldCheck className="text-green-500 w-10 h-10" />
              </div>
              <h2 className="text-2xl font-bold text-gray-800">Verify Identity</h2>
              <p className="text-gray-500 text-sm mt-2">
                We've sent a unique 6-digit code to <br/>
                <span className="font-bold text-blue-500">{selectedCountry.dial} {phoneNumber}</span>
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex justify-between gap-2">
                {otp.map((digit, i) => (
                  <input
                    key={i}
                    ref={el => otpRefs.current[i] = el}
                    type="tel"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(i, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(i, e)}
                    className="w-full aspect-square text-center text-2xl font-black bg-gray-50 border-2 border-gray-100 rounded-xl focus:border-[#6EC6FF] focus:bg-white outline-none transition-all text-[#6EC6FF]"
                    autoFocus={i === 0}
                  />
                ))}
              </div>

              <div className="text-center">
                {timer > 0 ? (
                  <p className="text-sm text-gray-400 font-bold">Request a new code in <span className="text-[#6EC6FF]">{timer}s</span></p>
                ) : (
                  <button 
                    onClick={handleSendOtp}
                    className="flex items-center gap-1 mx-auto text-sm font-bold text-blue-500 hover:text-blue-600 transition-colors"
                  >
                    <RefreshCw size={14} /> Resend Security Code
                  </button>
                )}
              </div>

              <div className="pt-2">
                <BubbleButton 
                  fullWidth 
                  onClick={handleVerifyOtp} 
                  variant="success" 
                  size="lg"
                  disabled={isVerifying || otp.join('').length < 6}
                >
                  {isVerifying ? <Loader2 className="animate-spin" /> : 'Confirm & Log In'}
                  {!isVerifying && <Check size={20} className="ml-2" />}
                </BubbleButton>
                
                <button 
                  onClick={() => { setStep('phone'); setIncomingSms({ visible: false, code: '' }); }}
                  className="w-full text-center mt-4 text-xs font-bold text-gray-400 hover:text-gray-600 transition-colors"
                >
                  Change mobile number
                </button>
              </div>
            </div>
          </div>
        )}
      </Card>
      
      <p className="mt-8 text-white/70 text-xs font-bold uppercase tracking-[0.2em] animate-pulse">
        Based in Jerusalem • Divine Tech Co. Ltd
      </p>

      <style>{`
        @keyframes ring {
          0%, 100% { transform: rotate(0); }
          10%, 30%, 50%, 70%, 90% { transform: rotate(-10deg); }
          20%, 40%, 60%, 80% { transform: rotate(10deg); }
        }
        .animate-ring {
          animation: ring 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};
